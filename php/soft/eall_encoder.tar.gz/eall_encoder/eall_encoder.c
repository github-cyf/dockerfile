/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2013 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_eall_encoder.h"
#include "miniz/miniz.h"
#include "xyssl/xyssl_md5.h"
#include "xyssl/xyssl_sha1.h"
#include "xyssl/xyssl_base64.h"
#include "xyssl/xyssl_rsa.h"
#include "xyssl/xyssl_arc4.h"
#include "xyssl/xyssl_havege.h"
#include "ell/ell.h"
#include "ell/lauxlib.h"
#include "ell/lobject.h"
#include "ell/lstate.h"
#include "ell/lundump.h"
#define MINIZ_MAXBUFFER 4194304

#include <string.h>

/* If you declare any globals in php_eall_encoder.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(eall_encoder)
*/

/* True global resources - no need for thread safety here */
static int le_eall_encoder;

/* {{{ eall_encoder_functions[]
 *
 * Every user visible function must have an entry in eall_encoder_functions[].
 */
const zend_function_entry eall_encoder_functions[] = {
	PHP_FE(confirm_eall_encoder_compiled,	NULL)		/* For testing, remove later. */
	PHP_FE(eall_encode,	NULL)
	PHP_FE(eall_compress,	NULL)
	PHP_FE(eall_uncompress,	NULL)
	PHP_FE(eall_rsa_encrypt,	NULL)
	PHP_FE(eall_rsa_decrypt,	NULL)
	PHP_FE(eall_rsa_genkey,	NULL)
	PHP_FE(eall_rc4,	NULL)
	PHP_FE(eall_compile,	NULL)
	PHP_FE(eall_compile32,	NULL)
	PHP_FE_END	/* Must be the last line in eall_encoder_functions[] */
};
/* }}} */

/* {{{ eall_encoder_module_entry
 */
zend_module_entry eall_encoder_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"eall_encoder",
	eall_encoder_functions,
	PHP_MINIT(eall_encoder),
	PHP_MSHUTDOWN(eall_encoder),
	PHP_RINIT(eall_encoder),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(eall_encoder),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(eall_encoder),
#if ZEND_MODULE_API_NO >= 20010901
	PHP_EALL_ENCODER_VERSION,
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_EALL_ENCODER
ZEND_GET_MODULE(eall_encoder)
#endif

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("eall_encoder.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_eall_encoder_globals, eall_encoder_globals)
    STD_PHP_INI_ENTRY("eall_encoder.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_eall_encoder_globals, eall_encoder_globals)
PHP_INI_END()
*/
/* }}} */

/* {{{ php_eall_encoder_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_eall_encoder_init_globals(zend_eall_encoder_globals *eall_encoder_globals)
{
	eall_encoder_globals->global_value = 0;
	eall_encoder_globals->global_string = NULL;
}
*/
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(eall_encoder)
{
	/* If you have INI entries, uncomment these lines 
	REGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(eall_encoder)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(eall_encoder)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(eall_encoder)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(eall_encoder)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "eall_encoder support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */


/* Remove the following function when you have successfully modified config.m4
   so that your module can be compiled into PHP, it exists only for testing
   purposes. */

PHP_FUNCTION(eall_compress) {
    char *str = NULL;
    char *buf;
    int argc = ZEND_NUM_ARGS();
    int str_len, compress_status;
    size_t buf_len;
    char *result;

    if (zend_parse_parameters(argc TSRMLS_CC, "s", &str, &str_len) == FAILURE) {
        return;
    }

    buf_len = compressBound(str_len);
    buf = (char *)emalloc(buf_len);
    compress_status = compress2((unsigned char *)buf, &buf_len, (unsigned char *)str, str_len, 10);
    if (compress_status != Z_OK) {
        efree(buf);
    } else {
        erealloc(buf, buf_len);
        RETURN_STRINGL(buf, buf_len, 0);
    }
}

PHP_FUNCTION(eall_uncompress) {
    char *str = NULL;
    char *buf;
    int argc = ZEND_NUM_ARGS();
    int str_len, compress_status;
    size_t buf_len = MINIZ_MAXBUFFER;
    char *result;

    if (zend_parse_parameters(argc TSRMLS_CC, "s", &str, &str_len) == FAILURE) {
        return;
    }

    buf = (char *)emalloc(buf_len);
    compress_status = uncompress((unsigned char *)buf, &buf_len, (unsigned char *)str, str_len);
    if (compress_status != Z_OK) {
        efree(buf);
    } else {
        erealloc(buf, buf_len);
        RETURN_STRINGL(buf, buf_len, 0);
    }
}

// N, E, D, P, Q, DP, DQ, QP
static int parse_rsa_key(rsa_context *rsa, char *key, int key_len) {
    mpi *X[] = { &rsa->N, &rsa->E, &rsa->D, &rsa->P, &rsa->Q,
        &rsa->DP, &rsa->DQ, &rsa->QP };
    char *p;
    int i = 0, diff = 0;
    for (i = 0; i < 8; i++) {
        p = memchr(key, '/', key_len);
        if (p == NULL) {
            break;
        }
        *p = '\0';
        if (mpi_read_string(X[i], 16, key) != 0) {
            return -1;
        }
        key_len-= p - key + 1;
        key = p + 1;
    }
    if (i == 8) {
        return RSA_PRIVATE;
    } else if (i == 2) {
        return RSA_PUBLIC;
    }
    return -1;
}

PHP_FUNCTION(eall_rsa_encrypt) {
    char *key, *src, *p;
    int key_len, src_len, mode;
    rsa_context rsa;
    char buf[1024] = {0};

    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &src, &src_len, &key, &key_len) == FAILURE) {
        return;
    }

    rsa_init(&rsa, RSA_PKCS_V15, 0, NULL, NULL);
    rsa.len = src_len;
    mode = parse_rsa_key(&rsa, key, key_len);
    if (mode < 0) {
        return;
    }

    rsa.len = (mpi_msb(&rsa.N) + 7) >> 3;

    if (rsa_pkcs1_encrypt(&rsa, mode, src_len, (unsigned char *)src, (unsigned char *)buf)) {
        return;
    }
    RETURN_STRINGL(buf, rsa.len, 1);
}

PHP_FUNCTION(eall_rsa_decrypt) {
    char *key, *src, *p;
    int key_len, src_len, mode;
    rsa_context rsa;
    char buf[1024] = {0};

    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &src, &src_len, &key, &key_len) == FAILURE) {
        return;
    }

    rsa_init(&rsa, RSA_PKCS_V15, 0, NULL, NULL);
    rsa.len = src_len;
    mode = parse_rsa_key(&rsa, key, key_len);
    if (mode < 0) {
        return;
    }
    if (rsa_pkcs1_decrypt(&rsa, mode, &src_len, (unsigned char *)src, (unsigned char *)buf)) {
        return;
    }
    RETURN_STRINGL(buf, src_len, 1);
}

PHP_FUNCTION(eall_rsa_genkey) {
}

typedef struct {
    char *buf;
    int len;
} ell_buffer;

static int buf_writer(ell_State* L, const void* src, size_t src_len, void* out) {
    ell_buffer *buf = (ell_buffer *)out;
    if (buf->buf == NULL) {
        buf->buf = (char *)emalloc(src_len);
    } else {
        buf->buf = erealloc(buf->buf, buf->len + src_len);
    }
    memcpy(buf->buf + buf->len, src, src_len);
    buf->len+= src_len;
    return 0;
}

PHP_FUNCTION(eall_compile32) {
    ell_buffer buf = {0};
    char *src;
    int src_len;
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &src, &src_len) == FAILURE) {
        return;
    }

    ellU_setbit(32);
    ell_State *L = ellL_newstate();
    if (ellL_loadbuffer(L, src, src_len, NULL) != ELL_OK) {
        return;
    }

    Proto* f = getproto(L->top - 1);
    ellU_dump(L, f, buf_writer, &buf, 1);

    ell_close(L);

    RETURN_STRINGL(buf.buf, buf.len, 0);
}

PHP_FUNCTION(eall_compile) {
    ell_buffer buf = {0};
    char *src;
    int src_len;
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &src, &src_len) == FAILURE) {
        return;
    }

    ellU_setbit(sizeof(size_t) * 8);
    ell_State *L = ellL_newstate();
    if (ellL_loadbuffer(L, src, src_len, NULL) != ELL_OK) {
        return;
    }

    Proto* f = getproto(L->top - 1);
    ellU_dump(L, f, buf_writer, &buf, 1);

    ell_close(L);

    RETURN_STRINGL(buf.buf, buf.len, 0);
}

PHP_FUNCTION(eall_rc4) {
    char *key, *src, *cipher;
    int key_len, src_len;
    arc4_context ctx;
    if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &src, &src_len, &key, &key_len) == FAILURE) {
        return;
    }
    cipher = (char *)emalloc(src_len);
    memcpy(cipher, src, src_len);

    arc4_setup(&ctx, (unsigned char *)key, key_len);
    arc4_crypt(&ctx, (unsigned char *)cipher, src_len);
    RETURN_STRINGL(cipher, src_len, 0);
}

PHP_FUNCTION(eall_encode) {
    char *str = NULL;
    int argc = ZEND_NUM_ARGS();
    int str_len;
    char *result;

    if (zend_parse_parameters(argc TSRMLS_CC, "s", &str, &str_len) == FAILURE) {
        return;
    }

    str_len = spprintf(&result, 0, "arg is %s", str);
    RETURN_STRINGL(result, str_len, 0);
}

/* Every user-visible function in PHP should document itself in the source */
/* {{{ proto string confirm_eall_encoder_compiled(string arg)
   Return a string to confirm that the module is compiled in */
PHP_FUNCTION(confirm_eall_encoder_compiled)
{
	char *arg = NULL;
	int arg_len, len;
	char *strg;

	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &arg, &arg_len) == FAILURE) {
		return;
	}

	len = spprintf(&strg, 0, "Congratulations! You have successfully modified ext/%.78s/config.m4. Module %.78s is now compiled into PHP.", "eall_encoder", arg);
	RETURN_STRINGL(strg, len, 0);
}
/* }}} */
/* The previous line is meant for vim and emacs, so it can correctly fold and 
   unfold functions in source code. See the corresponding marks just before 
   function definition, where the functions purpose is also documented. Please 
   follow this convention for the convenience of others editing your code.
*/


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
