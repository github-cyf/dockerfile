/*
** $Id: ltablib.c,v 1.65.1.1 2013/04/12 18:48:47 roberto Exp $
** Library for Table Manipulation
** See Copyright Notice in ell.h
*/


#include <stddef.h>

#define ltablib_c
#define ELL_LIB

#include "ell.h"

#include "lauxlib.h"
#include "elllib.h"


#define aux_getn(L,n)	(ellL_checktype(L, n, ELL_TTABLE), ellL_len(L, n))



#if defined(ELL_COMPAT_MAXN)
static int maxn (ell_State *L) {
  ell_Number max = 0;
  ellL_checktype(L, 1, ELL_TTABLE);
  ell_pushnil(L);  /* first key */
  while (ell_next(L, 1)) {
    ell_pop(L, 1);  /* remove value */
    if (ell_type(L, -1) == ELL_TNUMBER) {
      ell_Number v = ell_tonumber(L, -1);
      if (v > max) max = v;
    }
  }
  ell_pushnumber(L, max);
  return 1;
}
#endif


static int tinsert (ell_State *L) {
  int e = aux_getn(L, 1) + 1;  /* first empty element */
  int pos;  /* where to insert new element */
  switch (ell_gettop(L)) {
    case 2: {  /* called with only 2 arguments */
      pos = e;  /* insert new element at the end */
      break;
    }
    case 3: {
      int i;
      pos = ellL_checkint(L, 2);  /* 2nd argument is the position */
      ellL_argcheck(L, 1 <= pos && pos <= e, 2, "position out of bounds");
      for (i = e; i > pos; i--) {  /* move up elements */
        ell_rawgeti(L, 1, i-1);
        ell_rawseti(L, 1, i);  /* t[i] = t[i-1] */
      }
      break;
    }
    default: {
      return ellL_error(L, "wrong number of arguments to " ELL_QL("insert"));
    }
  }
  ell_rawseti(L, 1, pos);  /* t[pos] = v */
  return 0;
}


static int tremove (ell_State *L) {
  int size = aux_getn(L, 1);
  int pos = ellL_optint(L, 2, size);
  if (pos != size)  /* validate 'pos' if given */
    ellL_argcheck(L, 1 <= pos && pos <= size + 1, 1, "position out of bounds");
  ell_rawgeti(L, 1, pos);  /* result = t[pos] */
  for ( ; pos < size; pos++) {
    ell_rawgeti(L, 1, pos+1);
    ell_rawseti(L, 1, pos);  /* t[pos] = t[pos+1] */
  }
  ell_pushnil(L);
  ell_rawseti(L, 1, pos);  /* t[pos] = nil */
  return 1;
}


static void addfield (ell_State *L, ellL_Buffer *b, int i) {
  ell_rawgeti(L, 1, i);
  if (!ell_isstring(L, -1))
    ellL_error(L, "invalid value (%s) at index %d in table for "
                  ELL_QL("concat"), ellL_typename(L, -1), i);
  ellL_addvalue(b);
}


static int tconcat (ell_State *L) {
  ellL_Buffer b;
  size_t lsep;
  int i, last;
  const char *sep = ellL_optlstring(L, 2, "", &lsep);
  ellL_checktype(L, 1, ELL_TTABLE);
  i = ellL_optint(L, 3, 1);
  last = ellL_opt(L, ellL_checkint, 4, ellL_len(L, 1));
  ellL_buffinit(L, &b);
  for (; i < last; i++) {
    addfield(L, &b, i);
    ellL_addlstring(&b, sep, lsep);
  }
  if (i == last)  /* add last value (if interval was not empty) */
    addfield(L, &b, i);
  ellL_pushresult(&b);
  return 1;
}


/*
** {======================================================
** Pack/unpack
** =======================================================
*/

static int pack (ell_State *L) {
  int n = ell_gettop(L);  /* number of elements to pack */
  ell_createtable(L, n, 1);  /* create result table */
  ell_pushinteger(L, n);
  ell_setfield(L, -2, "n");  /* t.n = number of elements */
  if (n > 0) {  /* at least one element? */
    int i;
    ell_pushvalue(L, 1);
    ell_rawseti(L, -2, 1);  /* insert first element */
    ell_replace(L, 1);  /* move table into index 1 */
    for (i = n; i >= 2; i--)  /* assign other elements */
      ell_rawseti(L, 1, i);
  }
  return 1;  /* return table */
}


static int unpack (ell_State *L) {
  int i, e, n;
  ellL_checktype(L, 1, ELL_TTABLE);
  i = ellL_optint(L, 2, 1);
  e = ellL_opt(L, ellL_checkint, 3, ellL_len(L, 1));
  if (i > e) return 0;  /* empty range */
  n = e - i + 1;  /* number of elements */
  if (n <= 0 || !ell_checkstack(L, n))  /* n <= 0 means arith. overflow */
    return ellL_error(L, "too many results to unpack");
  ell_rawgeti(L, 1, i);  /* push arg[i] (avoiding overflow problems) */
  while (i++ < e)  /* push arg[i + 1...e] */
    ell_rawgeti(L, 1, i);
  return n;
}

/* }====================================================== */



/*
** {======================================================
** Quicksort
** (based on `Algorithms in MODULA-3', Robert Sedgewick;
**  Addison-Wesley, 1993.)
** =======================================================
*/


static void set2 (ell_State *L, int i, int j) {
  ell_rawseti(L, 1, i);
  ell_rawseti(L, 1, j);
}

static int sort_comp (ell_State *L, int a, int b) {
  if (!ell_isnil(L, 2)) {  /* function? */
    int res;
    ell_pushvalue(L, 2);
    ell_pushvalue(L, a-1);  /* -1 to compensate function */
    ell_pushvalue(L, b-2);  /* -2 to compensate function and `a' */
    ell_call(L, 2, 1);
    res = ell_toboolean(L, -1);
    ell_pop(L, 1);
    return res;
  }
  else  /* a < b? */
    return ell_compare(L, a, b, ELL_OPLT);
}

static void auxsort (ell_State *L, int l, int u) {
  while (l < u) {  /* for tail recursion */
    int i, j;
    /* sort elements a[l], a[(l+u)/2] and a[u] */
    ell_rawgeti(L, 1, l);
    ell_rawgeti(L, 1, u);
    if (sort_comp(L, -1, -2))  /* a[u] < a[l]? */
      set2(L, l, u);  /* swap a[l] - a[u] */
    else
      ell_pop(L, 2);
    if (u-l == 1) break;  /* only 2 elements */
    i = (l+u)/2;
    ell_rawgeti(L, 1, i);
    ell_rawgeti(L, 1, l);
    if (sort_comp(L, -2, -1))  /* a[i]<a[l]? */
      set2(L, i, l);
    else {
      ell_pop(L, 1);  /* remove a[l] */
      ell_rawgeti(L, 1, u);
      if (sort_comp(L, -1, -2))  /* a[u]<a[i]? */
        set2(L, i, u);
      else
        ell_pop(L, 2);
    }
    if (u-l == 2) break;  /* only 3 elements */
    ell_rawgeti(L, 1, i);  /* Pivot */
    ell_pushvalue(L, -1);
    ell_rawgeti(L, 1, u-1);
    set2(L, i, u-1);
    /* a[l] <= P == a[u-1] <= a[u], only need to sort from l+1 to u-2 */
    i = l; j = u-1;
    for (;;) {  /* invariant: a[l..i] <= P <= a[j..u] */
      /* repeat ++i until a[i] >= P */
      while (ell_rawgeti(L, 1, ++i), sort_comp(L, -1, -2)) {
        if (i>=u) ellL_error(L, "invalid order function for sorting");
        ell_pop(L, 1);  /* remove a[i] */
      }
      /* repeat --j until a[j] <= P */
      while (ell_rawgeti(L, 1, --j), sort_comp(L, -3, -1)) {
        if (j<=l) ellL_error(L, "invalid order function for sorting");
        ell_pop(L, 1);  /* remove a[j] */
      }
      if (j<i) {
        ell_pop(L, 3);  /* pop pivot, a[i], a[j] */
        break;
      }
      set2(L, i, j);
    }
    ell_rawgeti(L, 1, u-1);
    ell_rawgeti(L, 1, i);
    set2(L, u-1, i);  /* swap pivot (a[u-1]) with a[i] */
    /* a[l..i-1] <= a[i] == P <= a[i+1..u] */
    /* adjust so that smaller half is in [j..i] and larger one in [l..u] */
    if (i-l < u-i) {
      j=l; i=i-1; l=i+2;
    }
    else {
      j=i+1; i=u; u=j-2;
    }
    auxsort(L, j, i);  /* call recursively the smaller one */
  }  /* repeat the routine for the larger one */
}

static int sort (ell_State *L) {
  int n = aux_getn(L, 1);
  ellL_checkstack(L, 40, "");  /* assume array is smaller than 2^40 */
  if (!ell_isnoneornil(L, 2))  /* is there a 2nd argument? */
    ellL_checktype(L, 2, ELL_TFUNCTION);
  ell_settop(L, 2);  /* make sure there is two arguments */
  auxsort(L, 1, n);
  return 0;
}

/* }====================================================== */


static const ellL_Reg tab_funcs[] = {
  {"concat", tconcat},
#if defined(ELL_COMPAT_MAXN)
  {"maxn", maxn},
#endif
  {"insert", tinsert},
  {"pack", pack},
  {"unpack", unpack},
  {"remove", tremove},
  {"sort", sort},
  {NULL, NULL}
};


ELLMOD_API int ellopen_table (ell_State *L) {
  ellL_newlib(L, tab_funcs);
#if defined(ELL_COMPAT_UNPACK)
  /* _G.unpack = table.unpack */
  ell_getfield(L, -1, "unpack");
  ell_setglobal(L, "unpack");
#endif
  return 1;
}

