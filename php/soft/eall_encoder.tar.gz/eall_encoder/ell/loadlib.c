/*
** $Id: loadlib.c,v 1.111.1.1 2013/04/12 18:48:47 roberto Exp $
** Dynamic library loader for Ell
** See Copyright Notice in ell.h
**
** This module contains an implementation of loadlib for Unix systems
** that have dlfcn, an implementation for Windows, and a stub for other
** systems.
*/


/*
** if needed, includes windows header before everything else
*/
#if defined(_WIN32)
#include <windows.h>
#endif


#include <stdlib.h>
#include <string.h>


#define loadlib_c
#define ELL_LIB

#include "ell.h"

#include "lauxlib.h"
#include "elllib.h"


/*
** ELL_PATH and ELL_CPATH are the names of the environment
** variables that Ell check to set its paths.
*/
#if !defined(ELL_PATH)
#define ELL_PATH	"ELL_PATH"
#endif

#if !defined(ELL_CPATH)
#define ELL_CPATH	"ELL_CPATH"
#endif

#define ELL_PATHSUFFIX		"_" ELL_VERSION_MAJOR "_" ELL_VERSION_MINOR

#define ELL_PATHVERSION		ELL_PATH ELL_PATHSUFFIX
#define ELL_CPATHVERSION	ELL_CPATH ELL_PATHSUFFIX

/*
** ELL_PATH_SEP is the character that separates templates in a path.
** ELL_PATH_MARK is the string that marks the substitution points in a
** template.
** ELL_EXEC_DIR in a Windows path is replaced by the executable's
** directory.
** ELL_IGMARK is a mark to ignore all before it when building the
** ellopen_ function name.
*/
#if !defined (ELL_PATH_SEP)
#define ELL_PATH_SEP		";"
#endif
#if !defined (ELL_PATH_MARK)
#define ELL_PATH_MARK		"?"
#endif
#if !defined (ELL_EXEC_DIR)
#define ELL_EXEC_DIR		"!"
#endif
#if !defined (ELL_IGMARK)
#define ELL_IGMARK		"-"
#endif


/*
** ELL_CSUBSEP is the character that replaces dots in submodule names
** when searching for a C loader.
** ELL_LSUBSEP is the character that replaces dots in submodule names
** when searching for a Ell loader.
*/
#if !defined(ELL_CSUBSEP)
#define ELL_CSUBSEP		ELL_DIRSEP
#endif

#if !defined(ELL_LSUBSEP)
#define ELL_LSUBSEP		ELL_DIRSEP
#endif


/* prefix for open functions in C libraries */
#define ELL_POF		"ellopen_"

/* separator for open functions in C libraries */
#define ELL_OFSEP	"_"


/* table (in the registry) that keeps handles for all loaded C libraries */
#define CLIBS		"_CLIBS"

#define LIB_FAIL	"open"


/* error codes for ll_loadfunc */
#define ERRLIB		1
#define ERRFUNC		2

#define setprogdir(L)		((void)0)


/*
** system-dependent functions
*/
static void ll_unloadlib (void *lib);
static void *ll_load (ell_State *L, const char *path, int seeglb);
static ell_CFunction ll_sym (ell_State *L, void *lib, const char *sym);



#if defined(ELL_USE_DLOPEN)
/*
** {========================================================================
** This is an implementation of loadlib based on the dlfcn interface.
** The dlfcn interface is available in Linux, SunOS, Solaris, IRIX, FreeBSD,
** NetBSD, AIX 4.2, HPUX 11, and  probably most other Unix flavors, at least
** as an emulation layer on top of native functions.
** =========================================================================
*/

#include <dlfcn.h>

static void ll_unloadlib (void *lib) {
  dlclose(lib);
}


static void *ll_load (ell_State *L, const char *path, int seeglb) {
  void *lib = dlopen(path, RTLD_NOW | (seeglb ? RTLD_GLOBAL : RTLD_LOCAL));
  if (lib == NULL) ell_pushstring(L, dlerror());
  return lib;
}


static ell_CFunction ll_sym (ell_State *L, void *lib, const char *sym) {
  ell_CFunction f = (ell_CFunction)dlsym(lib, sym);
  if (f == NULL) ell_pushstring(L, dlerror());
  return f;
}

/* }====================================================== */



#elif defined(ELL_DL_DLL)
/*
** {======================================================================
** This is an implementation of loadlib for Windows using native functions.
** =======================================================================
*/

#undef setprogdir

/*
** optional flags for LoadLibraryEx
*/
#if !defined(ELL_LLE_FLAGS)
#define ELL_LLE_FLAGS	0
#endif


static void setprogdir (ell_State *L) {
  char buff[MAX_PATH + 1];
  char *lb;
  DWORD nsize = sizeof(buff)/sizeof(char);
  DWORD n = GetModuleFileNameA(NULL, buff, nsize);
  if (n == 0 || n == nsize || (lb = strrchr(buff, '\\')) == NULL)
    ellL_error(L, "unable to get ModuleFileName");
  else {
    *lb = '\0';
    ellL_gsub(L, ell_tostring(L, -1), ELL_EXEC_DIR, buff);
    ell_remove(L, -2);  /* remove original string */
  }
}


static void pusherror (ell_State *L) {
  int error = GetLastError();
  char buffer[128];
  if (FormatMessageA(FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM,
      NULL, error, 0, buffer, sizeof(buffer)/sizeof(char), NULL))
    ell_pushstring(L, buffer);
  else
    ell_pushfstring(L, "system error %d\n", error);
}

static void ll_unloadlib (void *lib) {
  FreeLibrary((HMODULE)lib);
}


static void *ll_load (ell_State *L, const char *path, int seeglb) {
  HMODULE lib = LoadLibraryExA(path, NULL, ELL_LLE_FLAGS);
  (void)(seeglb);  /* not used: symbols are 'global' by default */
  if (lib == NULL) pusherror(L);
  return lib;
}


static ell_CFunction ll_sym (ell_State *L, void *lib, const char *sym) {
  ell_CFunction f = (ell_CFunction)GetProcAddress((HMODULE)lib, sym);
  if (f == NULL) pusherror(L);
  return f;
}

/* }====================================================== */


#else
/*
** {======================================================
** Fallback for other systems
** =======================================================
*/

#undef LIB_FAIL
#define LIB_FAIL	"absent"


#define DLMSG	"dynamic libraries not enabled; check your Ell installation"


static void ll_unloadlib (void *lib) {
  (void)(lib);  /* not used */
}


static void *ll_load (ell_State *L, const char *path, int seeglb) {
  (void)(path); (void)(seeglb);  /* not used */
  ell_pushliteral(L, DLMSG);
  return NULL;
}


static ell_CFunction ll_sym (ell_State *L, void *lib, const char *sym) {
  (void)(lib); (void)(sym);  /* not used */
  ell_pushliteral(L, DLMSG);
  return NULL;
}

/* }====================================================== */
#endif


static void *ll_checkclib (ell_State *L, const char *path) {
  void *plib;
  ell_getfield(L, ELL_REGISTRYINDEX, CLIBS);
  ell_getfield(L, -1, path);
  plib = ell_touserdata(L, -1);  /* plib = CLIBS[path] */
  ell_pop(L, 2);  /* pop CLIBS table and 'plib' */
  return plib;
}


static void ll_addtoclib (ell_State *L, const char *path, void *plib) {
  ell_getfield(L, ELL_REGISTRYINDEX, CLIBS);
  ell_pushlightuserdata(L, plib);
  ell_pushvalue(L, -1);
  ell_setfield(L, -3, path);  /* CLIBS[path] = plib */
  ell_rawseti(L, -2, ellL_len(L, -2) + 1);  /* CLIBS[#CLIBS + 1] = plib */
  ell_pop(L, 1);  /* pop CLIBS table */
}


/*
** __gc tag method for CLIBS table: calls 'll_unloadlib' for all lib
** handles in list CLIBS
*/
static int gctm (ell_State *L) {
  int n = ellL_len(L, 1);
  for (; n >= 1; n--) {  /* for each handle, in reverse order */
    ell_rawgeti(L, 1, n);  /* get handle CLIBS[n] */
    ll_unloadlib(ell_touserdata(L, -1));
    ell_pop(L, 1);  /* pop handle */
  }
  return 0;
}


static int ll_loadfunc (ell_State *L, const char *path, const char *sym) {
  void *reg = ll_checkclib(L, path);  /* check loaded C libraries */
  if (reg == NULL) {  /* must load library? */
    reg = ll_load(L, path, *sym == '*');
    if (reg == NULL) return ERRLIB;  /* unable to load library */
    ll_addtoclib(L, path, reg);
  }
  if (*sym == '*') {  /* loading only library (no function)? */
    ell_pushboolean(L, 1);  /* return 'true' */
    return 0;  /* no errors */
  }
  else {
    ell_CFunction f = ll_sym(L, reg, sym);
    if (f == NULL)
      return ERRFUNC;  /* unable to find function */
    ell_pushcfunction(L, f);  /* else create new function */
    return 0;  /* no errors */
  }
}


static int ll_loadlib (ell_State *L) {
  const char *path = ellL_checkstring(L, 1);
  const char *init = ellL_checkstring(L, 2);
  int stat = ll_loadfunc(L, path, init);
  if (stat == 0)  /* no errors? */
    return 1;  /* return the loaded function */
  else {  /* error; error message is on stack top */
    ell_pushnil(L);
    ell_insert(L, -2);
    ell_pushstring(L, (stat == ERRLIB) ?  LIB_FAIL : "init");
    return 3;  /* return nil, error message, and where */
  }
}



/*
** {======================================================
** 'require' function
** =======================================================
*/


static int readable (const char *filename) {
  FILE *f = fopen(filename, "r");  /* try to open file */
  if (f == NULL) return 0;  /* open failed */
  fclose(f);
  return 1;
}


static const char *pushnexttemplate (ell_State *L, const char *path) {
  const char *l;
  while (*path == *ELL_PATH_SEP) path++;  /* skip separators */
  if (*path == '\0') return NULL;  /* no more templates */
  l = strchr(path, *ELL_PATH_SEP);  /* find next separator */
  if (l == NULL) l = path + strlen(path);
  ell_pushlstring(L, path, l - path);  /* template */
  return l;
}


static const char *searchpath (ell_State *L, const char *name,
                                             const char *path,
                                             const char *sep,
                                             const char *dirsep) {
  ellL_Buffer msg;  /* to build error message */
  ellL_buffinit(L, &msg);
  if (*sep != '\0')  /* non-empty separator? */
    name = ellL_gsub(L, name, sep, dirsep);  /* replace it by 'dirsep' */
  while ((path = pushnexttemplate(L, path)) != NULL) {
    const char *filename = ellL_gsub(L, ell_tostring(L, -1),
                                     ELL_PATH_MARK, name);
    ell_remove(L, -2);  /* remove path template */
    if (readable(filename))  /* does file exist and is readable? */
      return filename;  /* return that file name */
    ell_pushfstring(L, "\n\tno file " ELL_QS, filename);
    ell_remove(L, -2);  /* remove file name */
    ellL_addvalue(&msg);  /* concatenate error msg. entry */
  }
  ellL_pushresult(&msg);  /* create error message */
  return NULL;  /* not found */
}


static int ll_searchpath (ell_State *L) {
  const char *f = searchpath(L, ellL_checkstring(L, 1),
                                ellL_checkstring(L, 2),
                                ellL_optstring(L, 3, "."),
                                ellL_optstring(L, 4, ELL_DIRSEP));
  if (f != NULL) return 1;
  else {  /* error message is on top of the stack */
    ell_pushnil(L);
    ell_insert(L, -2);
    return 2;  /* return nil + error message */
  }
}


static const char *findfile (ell_State *L, const char *name,
                                           const char *pname,
                                           const char *dirsep) {
  const char *path;
  ell_getfield(L, ell_upvalueindex(1), pname);
  path = ell_tostring(L, -1);
  if (path == NULL)
    ellL_error(L, ELL_QL("package.%s") " must be a string", pname);
  return searchpath(L, name, path, ".", dirsep);
}


static int checkload (ell_State *L, int stat, const char *filename) {
  if (stat) {  /* module loaded successfully? */
    ell_pushstring(L, filename);  /* will be 2nd argument to module */
    return 2;  /* return open function and file name */
  }
  else
    return ellL_error(L, "error loading module " ELL_QS
                         " from file " ELL_QS ":\n\t%s",
                          ell_tostring(L, 1), filename, ell_tostring(L, -1));
}


static int searcher_Ell (ell_State *L) {
  const char *filename;
  const char *name = ellL_checkstring(L, 1);
  filename = findfile(L, name, "path", ELL_LSUBSEP);
  if (filename == NULL) return 1;  /* module not found in this path */
  return checkload(L, (ellL_loadfile(L, filename) == ELL_OK), filename);
}


static int loadfunc (ell_State *L, const char *filename, const char *modname) {
  const char *funcname;
  const char *mark;
  modname = ellL_gsub(L, modname, ".", ELL_OFSEP);
  mark = strchr(modname, *ELL_IGMARK);
  if (mark) {
    int stat;
    funcname = ell_pushlstring(L, modname, mark - modname);
    funcname = ell_pushfstring(L, ELL_POF"%s", funcname);
    stat = ll_loadfunc(L, filename, funcname);
    if (stat != ERRFUNC) return stat;
    modname = mark + 1;  /* else go ahead and try old-style name */
  }
  funcname = ell_pushfstring(L, ELL_POF"%s", modname);
  return ll_loadfunc(L, filename, funcname);
}


static int searcher_C (ell_State *L) {
  const char *name = ellL_checkstring(L, 1);
  const char *filename = findfile(L, name, "cpath", ELL_CSUBSEP);
  if (filename == NULL) return 1;  /* module not found in this path */
  return checkload(L, (loadfunc(L, filename, name) == 0), filename);
}


static int searcher_Croot (ell_State *L) {
  const char *filename;
  const char *name = ellL_checkstring(L, 1);
  const char *p = strchr(name, '.');
  int stat;
  if (p == NULL) return 0;  /* is root */
  ell_pushlstring(L, name, p - name);
  filename = findfile(L, ell_tostring(L, -1), "cpath", ELL_CSUBSEP);
  if (filename == NULL) return 1;  /* root not found */
  if ((stat = loadfunc(L, filename, name)) != 0) {
    if (stat != ERRFUNC)
      return checkload(L, 0, filename);  /* real error */
    else {  /* open function not found */
      ell_pushfstring(L, "\n\tno module " ELL_QS " in file " ELL_QS,
                         name, filename);
      return 1;
    }
  }
  ell_pushstring(L, filename);  /* will be 2nd argument to module */
  return 2;
}


static int searcher_preload (ell_State *L) {
  const char *name = ellL_checkstring(L, 1);
  ell_getfield(L, ELL_REGISTRYINDEX, "_PRELOAD");
  ell_getfield(L, -1, name);
  if (ell_isnil(L, -1))  /* not found? */
    ell_pushfstring(L, "\n\tno field package.preload['%s']", name);
  return 1;
}


static void findloader (ell_State *L, const char *name) {
  int i;
  ellL_Buffer msg;  /* to build error message */
  ellL_buffinit(L, &msg);
  ell_getfield(L, ell_upvalueindex(1), "searchers");  /* will be at index 3 */
  if (!ell_istable(L, 3))
    ellL_error(L, ELL_QL("package.searchers") " must be a table");
  /*  iterate over available searchers to find a loader */
  for (i = 1; ; i++) {
    ell_rawgeti(L, 3, i);  /* get a searcher */
    if (ell_isnil(L, -1)) {  /* no more searchers? */
      ell_pop(L, 1);  /* remove nil */
      ellL_pushresult(&msg);  /* create error message */
      ellL_error(L, "module " ELL_QS " not found:%s",
                    name, ell_tostring(L, -1));
    }
    ell_pushstring(L, name);
    ell_call(L, 1, 2);  /* call it */
    if (ell_isfunction(L, -2))  /* did it find a loader? */
      return;  /* module loader found */
    else if (ell_isstring(L, -2)) {  /* searcher returned error message? */
      ell_pop(L, 1);  /* remove extra return */
      ellL_addvalue(&msg);  /* concatenate error message */
    }
    else
      ell_pop(L, 2);  /* remove both returns */
  }
}


static int ll_require (ell_State *L) {
  const char *name = ellL_checkstring(L, 1);
  ell_settop(L, 1);  /* _LOADED table will be at index 2 */
  ell_getfield(L, ELL_REGISTRYINDEX, "_LOADED");
  ell_getfield(L, 2, name);  /* _LOADED[name] */
  if (ell_toboolean(L, -1))  /* is it there? */
    return 1;  /* package is already loaded */
  /* else must load package */
  ell_pop(L, 1);  /* remove 'getfield' result */
  findloader(L, name);
  ell_pushstring(L, name);  /* pass name as argument to module loader */
  ell_insert(L, -2);  /* name is 1st argument (before search data) */
  ell_call(L, 2, 1);  /* run loader to load module */
  if (!ell_isnil(L, -1))  /* non-nil return? */
    ell_setfield(L, 2, name);  /* _LOADED[name] = returned value */
  ell_getfield(L, 2, name);
  if (ell_isnil(L, -1)) {   /* module did not set a value? */
    ell_pushboolean(L, 1);  /* use true as result */
    ell_pushvalue(L, -1);  /* extra copy to be returned */
    ell_setfield(L, 2, name);  /* _LOADED[name] = true */
  }
  return 1;
}

/* }====================================================== */



/*
** {======================================================
** 'module' function
** =======================================================
*/
#if defined(ELL_COMPAT_MODULE)

/*
** changes the environment variable of calling function
*/
static void set_env (ell_State *L) {
  ell_Debug ar;
  if (ell_getstack(L, 1, &ar) == 0 ||
      ell_getinfo(L, "f", &ar) == 0 ||  /* get calling function */
      ell_iscfunction(L, -1))
    ellL_error(L, ELL_QL("module") " not called from a Ell function");
  ell_pushvalue(L, -2);  /* copy new environment table to top */
  ell_setupvalue(L, -2, 1);
  ell_pop(L, 1);  /* remove function */
}


static void dooptions (ell_State *L, int n) {
  int i;
  for (i = 2; i <= n; i++) {
    if (ell_isfunction(L, i)) {  /* avoid 'calling' extra info. */
      ell_pushvalue(L, i);  /* get option (a function) */
      ell_pushvalue(L, -2);  /* module */
      ell_call(L, 1, 0);
    }
  }
}


static void modinit (ell_State *L, const char *modname) {
  const char *dot;
  ell_pushvalue(L, -1);
  ell_setfield(L, -2, "_M");  /* module._M = module */
  ell_pushstring(L, modname);
  ell_setfield(L, -2, "_NAME");
  dot = strrchr(modname, '.');  /* look for last dot in module name */
  if (dot == NULL) dot = modname;
  else dot++;
  /* set _PACKAGE as package name (full module name minus last part) */
  ell_pushlstring(L, modname, dot - modname);
  ell_setfield(L, -2, "_PACKAGE");
}


static int ll_module (ell_State *L) {
  const char *modname = ellL_checkstring(L, 1);
  int lastarg = ell_gettop(L);  /* last parameter */
  ellL_pushmodule(L, modname, 1);  /* get/create module table */
  /* check whether table already has a _NAME field */
  ell_getfield(L, -1, "_NAME");
  if (!ell_isnil(L, -1))  /* is table an initialized module? */
    ell_pop(L, 1);
  else {  /* no; initialize it */
    ell_pop(L, 1);
    modinit(L, modname);
  }
  ell_pushvalue(L, -1);
  set_env(L);
  dooptions(L, lastarg);
  return 1;
}


static int ll_seeall (ell_State *L) {
  ellL_checktype(L, 1, ELL_TTABLE);
  if (!ell_getmetatable(L, 1)) {
    ell_createtable(L, 0, 1); /* create new metatable */
    ell_pushvalue(L, -1);
    ell_setmetatable(L, 1);
  }
  ell_pushglobaltable(L);
  ell_setfield(L, -2, "__index");  /* mt.__index = _G */
  return 0;
}

#endif
/* }====================================================== */



/* auxiliary mark (for internal use) */
#define AUXMARK		"\1"


/*
** return registry.ELL_NOENV as a boolean
*/
static int noenv (ell_State *L) {
  int b;
  ell_getfield(L, ELL_REGISTRYINDEX, "ELL_NOENV");
  b = ell_toboolean(L, -1);
  ell_pop(L, 1);  /* remove value */
  return b;
}


static void setpath (ell_State *L, const char *fieldname, const char *envname1,
                                   const char *envname2, const char *def) {
  const char *path = getenv(envname1);
  if (path == NULL)  /* no environment variable? */
    path = getenv(envname2);  /* try alternative name */
  if (path == NULL || noenv(L))  /* no environment variable? */
    ell_pushstring(L, def);  /* use default */
  else {
    /* replace ";;" by ";AUXMARK;" and then AUXMARK by default path */
    path = ellL_gsub(L, path, ELL_PATH_SEP ELL_PATH_SEP,
                              ELL_PATH_SEP AUXMARK ELL_PATH_SEP);
    ellL_gsub(L, path, AUXMARK, def);
    ell_remove(L, -2);
  }
  setprogdir(L);
  ell_setfield(L, -2, fieldname);
}


static const ellL_Reg pk_funcs[] = {
  {"loadlib", ll_loadlib},
  {"searchpath", ll_searchpath},
#if defined(ELL_COMPAT_MODULE)
  {"seeall", ll_seeall},
#endif
  {NULL, NULL}
};


static const ellL_Reg ll_funcs[] = {
#if defined(ELL_COMPAT_MODULE)
  {"module", ll_module},
#endif
  {"require", ll_require},
  {NULL, NULL}
};


static void createsearcherstable (ell_State *L) {
  static const ell_CFunction searchers[] =
    {searcher_preload, searcher_Ell, searcher_C, searcher_Croot, NULL};
  int i;
  /* create 'searchers' table */
  ell_createtable(L, sizeof(searchers)/sizeof(searchers[0]) - 1, 0);
  /* fill it with pre-defined searchers */
  for (i=0; searchers[i] != NULL; i++) {
    ell_pushvalue(L, -2);  /* set 'package' as upvalue for all searchers */
    ell_pushcclosure(L, searchers[i], 1);
    ell_rawseti(L, -2, i+1);
  }
}


ELLMOD_API int ellopen_package (ell_State *L) {
  /* create table CLIBS to keep track of loaded C libraries */
  ellL_getsubtable(L, ELL_REGISTRYINDEX, CLIBS);
  ell_createtable(L, 0, 1);  /* metatable for CLIBS */
  ell_pushcfunction(L, gctm);
  ell_setfield(L, -2, "__gc");  /* set finalizer for CLIBS table */
  ell_setmetatable(L, -2);
  /* create `package' table */
  ellL_newlib(L, pk_funcs);
  createsearcherstable(L);
#if defined(ELL_COMPAT_LOADERS)
  ell_pushvalue(L, -1);  /* make a copy of 'searchers' table */
  ell_setfield(L, -3, "loaders");  /* put it in field `loaders' */
#endif
  ell_setfield(L, -2, "searchers");  /* put it in field 'searchers' */
  /* set field 'path' */
  setpath(L, "path", ELL_PATHVERSION, ELL_PATH, ELL_PATH_DEFAULT);
  /* set field 'cpath' */
  setpath(L, "cpath", ELL_CPATHVERSION, ELL_CPATH, ELL_CPATH_DEFAULT);
  /* store config information */
  ell_pushliteral(L, ELL_DIRSEP "\n" ELL_PATH_SEP "\n" ELL_PATH_MARK "\n"
                     ELL_EXEC_DIR "\n" ELL_IGMARK "\n");
  ell_setfield(L, -2, "config");
  /* set field `loaded' */
  ellL_getsubtable(L, ELL_REGISTRYINDEX, "_LOADED");
  ell_setfield(L, -2, "loaded");
  /* set field `preload' */
  ellL_getsubtable(L, ELL_REGISTRYINDEX, "_PRELOAD");
  ell_setfield(L, -2, "preload");
  ell_pushglobaltable(L);
  ell_pushvalue(L, -2);  /* set 'package' as upvalue for next lib */
  ellL_setfuncs(L, ll_funcs, 1);  /* open lib into global table */
  ell_pop(L, 1);  /* pop global table */
  return 1;  /* return 'package' table */
}

