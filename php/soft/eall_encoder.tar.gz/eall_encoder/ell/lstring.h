/*
** $Id: lstring.h,v 1.49.1.1 2013/04/12 18:48:47 roberto Exp $
** String table (keep all strings handled by Ell)
** See Copyright Notice in ell.h
*/

#ifndef lstring_h
#define lstring_h

#include "lgc.h"
#include "lobject.h"
#include "lstate.h"


#define sizestring(s)	(sizeof(union TString)+((s)->len+1)*sizeof(char))

#define sizeudata(u)	(sizeof(union Udata)+(u)->len)

#define ellS_newliteral(L, s)	(ellS_newlstr(L, "" s, \
                                 (sizeof(s)/sizeof(char))-1))

#define ellS_fix(s)	l_setbit((s)->tsv.marked, FIXEDBIT)


/*
** test whether a string is a reserved word
*/
#define isreserved(s)	((s)->tsv.tt == ELL_TSHRSTR && (s)->tsv.extra > 0)


/*
** equality for short strings, which are always internalized
*/
#define eqshrstr(a,b)	check_exp((a)->tsv.tt == ELL_TSHRSTR, (a) == (b))


ELLI_FUNC unsigned int ellS_hash (const char *str, size_t l, unsigned int seed);
ELLI_FUNC int ellS_eqlngstr (TString *a, TString *b);
ELLI_FUNC int ellS_eqstr (TString *a, TString *b);
ELLI_FUNC void ellS_resize (ell_State *L, int newsize);
ELLI_FUNC Udata *ellS_newudata (ell_State *L, size_t s, Table *e);
ELLI_FUNC TString *ellS_newlstr (ell_State *L, const char *str, size_t l);
ELLI_FUNC TString *ellS_new (ell_State *L, const char *str);


#endif
