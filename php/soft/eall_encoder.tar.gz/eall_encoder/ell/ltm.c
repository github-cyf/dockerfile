/*
** $Id: ltm.c,v 2.14.1.1 2013/04/12 18:48:47 roberto Exp $
** Tag methods
** See Copyright Notice in ell.h
*/


#include <string.h>

#define ltm_c
#define ELL_CORE

#include "ell.h"

#include "lobject.h"
#include "lstate.h"
#include "lstring.h"
#include "ltable.h"
#include "ltm.h"


static const char udatatypename[] = "userdata";

ELLI_DDEF const char *const ellT_typenames_[ELL_TOTALTAGS] = {
  "no value",
  "nil", "boolean", udatatypename, "number",
  "string", "table", "function", udatatypename, "thread",
  "proto", "upval"  /* these last two cases are used for tests only */
};


void ellT_init (ell_State *L) {
  static const char *const ellT_eventname[] = {  /* ORDER TM */
    "__index", "__newindex",
    "__gc", "__mode", "__len", "__eq",
    "__div", "__pow", "__add", "__mod", "__sub", "__mul",
    "__unm", "__le", "__lt",
    "__concat", "__call"
  };
  int i;
  for (i=0; i<TM_N; i++) {
    G(L)->tmname[i] = ellS_new(L, ellT_eventname[i]);
    ellS_fix(G(L)->tmname[i]);  /* never collect these names */
  }
}


/*
** function to be used with macro "fasttm": optimized for absence of
** tag methods
*/
const TValue *ellT_gettm (Table *events, TMS event, TString *ename) {
  const TValue *tm = ellH_getstr(events, ename);
  ell_assert(event <= TM_EQ);
  if (ttisnil(tm)) {  /* no tag method? */
    events->flags |= cast_byte(1u<<event);  /* cache this fact */
    return NULL;
  }
  else return tm;
}


const TValue *ellT_gettmbyobj (ell_State *L, const TValue *o, TMS event) {
  Table *mt;
  switch (ttypenv(o)) {
    case ELL_TTABLE:
      mt = hvalue(o)->metatable;
      break;
    case ELL_TUSERDATA:
      mt = uvalue(o)->metatable;
      break;
    default:
      mt = G(L)->mt[ttypenv(o)];
  }
  return (mt ? ellH_getstr(mt, G(L)->tmname[event]) : ellO_nilobject);
}

