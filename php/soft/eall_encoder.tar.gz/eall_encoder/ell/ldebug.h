/*
** $Id: ldebug.h,v 2.7.1.1 2013/04/12 18:48:47 roberto Exp $
** Auxiliary functions from Debug Interface module
** See Copyright Notice in ell.h
*/

#ifndef ldebug_h
#define ldebug_h


#include "lstate.h"


#define pcRel(pc, p)	(cast(int, (pc) - (p)->code) - 1)

#define getfuncline(f,pc)	(((f)->lineinfo) ? (f)->lineinfo[pc] : 0)

#define resethookcount(L)	(L->hookcount = L->basehookcount)

/* Active Ell function (given call info) */
#define ci_func(ci)		(clLvalue((ci)->func))


ELLI_FUNC l_noret ellG_typeerror (ell_State *L, const TValue *o,
                                                const char *opname);
ELLI_FUNC l_noret ellG_concaterror (ell_State *L, StkId p1, StkId p2);
ELLI_FUNC l_noret ellG_aritherror (ell_State *L, const TValue *p1,
                                                 const TValue *p2);
ELLI_FUNC l_noret ellG_ordererror (ell_State *L, const TValue *p1,
                                                 const TValue *p2);
ELLI_FUNC l_noret ellG_runerror (ell_State *L, const char *fmt, ...);
ELLI_FUNC l_noret ellG_errormsg (ell_State *L);

#endif
