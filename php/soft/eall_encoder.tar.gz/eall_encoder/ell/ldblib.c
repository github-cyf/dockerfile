/*
** $Id: ldblib.c,v 1.132.1.1 2013/04/12 18:48:47 roberto Exp $
** Interface from Ell to its debug API
** See Copyright Notice in ell.h
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ldblib_c
#define ELL_LIB

#include "ell.h"

#include "lauxlib.h"
#include "elllib.h"


#define HOOKKEY		"_HKEY"



static int db_getregistry (ell_State *L) {
  ell_pushvalue(L, ELL_REGISTRYINDEX);
  return 1;
}


static int db_getmetatable (ell_State *L) {
  ellL_checkany(L, 1);
  if (!ell_getmetatable(L, 1)) {
    ell_pushnil(L);  /* no metatable */
  }
  return 1;
}


static int db_setmetatable (ell_State *L) {
  int t = ell_type(L, 2);
  ellL_argcheck(L, t == ELL_TNIL || t == ELL_TTABLE, 2,
                    "nil or table expected");
  ell_settop(L, 2);
  ell_setmetatable(L, 1);
  return 1;  /* return 1st argument */
}


static int db_getuservalue (ell_State *L) {
  if (ell_type(L, 1) != ELL_TUSERDATA)
    ell_pushnil(L);
  else
    ell_getuservalue(L, 1);
  return 1;
}


static int db_setuservalue (ell_State *L) {
  if (ell_type(L, 1) == ELL_TLIGHTUSERDATA)
    ellL_argerror(L, 1, "full userdata expected, got light userdata");
  ellL_checktype(L, 1, ELL_TUSERDATA);
  if (!ell_isnoneornil(L, 2))
    ellL_checktype(L, 2, ELL_TTABLE);
  ell_settop(L, 2);
  ell_setuservalue(L, 1);
  return 1;
}


static void settabss (ell_State *L, const char *i, const char *v) {
  ell_pushstring(L, v);
  ell_setfield(L, -2, i);
}


static void settabsi (ell_State *L, const char *i, int v) {
  ell_pushinteger(L, v);
  ell_setfield(L, -2, i);
}


static void settabsb (ell_State *L, const char *i, int v) {
  ell_pushboolean(L, v);
  ell_setfield(L, -2, i);
}


static ell_State *getthread (ell_State *L, int *arg) {
  if (ell_isthread(L, 1)) {
    *arg = 1;
    return ell_tothread(L, 1);
  }
  else {
    *arg = 0;
    return L;
  }
}


static void treatstackoption (ell_State *L, ell_State *L1, const char *fname) {
  if (L == L1) {
    ell_pushvalue(L, -2);
    ell_remove(L, -3);
  }
  else
    ell_xmove(L1, L, 1);
  ell_setfield(L, -2, fname);
}


static int db_getinfo (ell_State *L) {
  ell_Debug ar;
  int arg;
  ell_State *L1 = getthread(L, &arg);
  const char *options = ellL_optstring(L, arg+2, "flnStu");
  if (ell_isnumber(L, arg+1)) {
    if (!ell_getstack(L1, (int)ell_tointeger(L, arg+1), &ar)) {
      ell_pushnil(L);  /* level out of range */
      return 1;
    }
  }
  else if (ell_isfunction(L, arg+1)) {
    ell_pushfstring(L, ">%s", options);
    options = ell_tostring(L, -1);
    ell_pushvalue(L, arg+1);
    ell_xmove(L, L1, 1);
  }
  else
    return ellL_argerror(L, arg+1, "function or level expected");
  if (!ell_getinfo(L1, options, &ar))
    return ellL_argerror(L, arg+2, "invalid option");
  ell_createtable(L, 0, 2);
  if (strchr(options, 'S')) {
    settabss(L, "source", ar.source);
    settabss(L, "short_src", ar.short_src);
    settabsi(L, "linedefined", ar.linedefined);
    settabsi(L, "lastlinedefined", ar.lastlinedefined);
    settabss(L, "what", ar.what);
  }
  if (strchr(options, 'l'))
    settabsi(L, "currentline", ar.currentline);
  if (strchr(options, 'u')) {
    settabsi(L, "nups", ar.nups);
    settabsi(L, "nparams", ar.nparams);
    settabsb(L, "isvararg", ar.isvararg);
  }
  if (strchr(options, 'n')) {
    settabss(L, "name", ar.name);
    settabss(L, "namewhat", ar.namewhat);
  }
  if (strchr(options, 't'))
    settabsb(L, "istailcall", ar.istailcall);
  if (strchr(options, 'L'))
    treatstackoption(L, L1, "activelines");
  if (strchr(options, 'f'))
    treatstackoption(L, L1, "func");
  return 1;  /* return table */
}


static int db_getlocal (ell_State *L) {
  int arg;
  ell_State *L1 = getthread(L, &arg);
  ell_Debug ar;
  const char *name;
  int nvar = ellL_checkint(L, arg+2);  /* local-variable index */
  if (ell_isfunction(L, arg + 1)) {  /* function argument? */
    ell_pushvalue(L, arg + 1);  /* push function */
    ell_pushstring(L, ell_getlocal(L, NULL, nvar));  /* push local name */
    return 1;
  }
  else {  /* stack-level argument */
    if (!ell_getstack(L1, ellL_checkint(L, arg+1), &ar))  /* out of range? */
      return ellL_argerror(L, arg+1, "level out of range");
    name = ell_getlocal(L1, &ar, nvar);
    if (name) {
      ell_xmove(L1, L, 1);  /* push local value */
      ell_pushstring(L, name);  /* push name */
      ell_pushvalue(L, -2);  /* re-order */
      return 2;
    }
    else {
      ell_pushnil(L);  /* no name (nor value) */
      return 1;
    }
  }
}


static int db_setlocal (ell_State *L) {
  int arg;
  ell_State *L1 = getthread(L, &arg);
  ell_Debug ar;
  if (!ell_getstack(L1, ellL_checkint(L, arg+1), &ar))  /* out of range? */
    return ellL_argerror(L, arg+1, "level out of range");
  ellL_checkany(L, arg+3);
  ell_settop(L, arg+3);
  ell_xmove(L, L1, 1);
  ell_pushstring(L, ell_setlocal(L1, &ar, ellL_checkint(L, arg+2)));
  return 1;
}


static int auxupvalue (ell_State *L, int get) {
  const char *name;
  int n = ellL_checkint(L, 2);
  ellL_checktype(L, 1, ELL_TFUNCTION);
  name = get ? ell_getupvalue(L, 1, n) : ell_setupvalue(L, 1, n);
  if (name == NULL) return 0;
  ell_pushstring(L, name);
  ell_insert(L, -(get+1));
  return get + 1;
}


static int db_getupvalue (ell_State *L) {
  return auxupvalue(L, 1);
}


static int db_setupvalue (ell_State *L) {
  ellL_checkany(L, 3);
  return auxupvalue(L, 0);
}


static int checkupval (ell_State *L, int argf, int argnup) {
  ell_Debug ar;
  int nup = ellL_checkint(L, argnup);
  ellL_checktype(L, argf, ELL_TFUNCTION);
  ell_pushvalue(L, argf);
  ell_getinfo(L, ">u", &ar);
  ellL_argcheck(L, 1 <= nup && nup <= ar.nups, argnup, "invalid upvalue index");
  return nup;
}


static int db_upvalueid (ell_State *L) {
  int n = checkupval(L, 1, 2);
  ell_pushlightuserdata(L, ell_upvalueid(L, 1, n));
  return 1;
}


static int db_upvaluejoin (ell_State *L) {
  int n1 = checkupval(L, 1, 2);
  int n2 = checkupval(L, 3, 4);
  ellL_argcheck(L, !ell_iscfunction(L, 1), 1, "Ell function expected");
  ellL_argcheck(L, !ell_iscfunction(L, 3), 3, "Ell function expected");
  ell_upvaluejoin(L, 1, n1, 3, n2);
  return 0;
}


#define gethooktable(L)	ellL_getsubtable(L, ELL_REGISTRYINDEX, HOOKKEY)


static void hookf (ell_State *L, ell_Debug *ar) {
  static const char *const hooknames[] =
    {"call", "return", "line", "count", "tail call"};
  gethooktable(L);
  ell_pushthread(L);
  ell_rawget(L, -2);
  if (ell_isfunction(L, -1)) {
    ell_pushstring(L, hooknames[(int)ar->event]);
    if (ar->currentline >= 0)
      ell_pushinteger(L, ar->currentline);
    else ell_pushnil(L);
    ell_assert(ell_getinfo(L, "lS", ar));
    ell_call(L, 2, 0);
  }
}


static int makemask (const char *smask, int count) {
  int mask = 0;
  if (strchr(smask, 'c')) mask |= ELL_MASKCALL;
  if (strchr(smask, 'r')) mask |= ELL_MASKRET;
  if (strchr(smask, 'l')) mask |= ELL_MASKLINE;
  if (count > 0) mask |= ELL_MASKCOUNT;
  return mask;
}


static char *unmakemask (int mask, char *smask) {
  int i = 0;
  if (mask & ELL_MASKCALL) smask[i++] = 'c';
  if (mask & ELL_MASKRET) smask[i++] = 'r';
  if (mask & ELL_MASKLINE) smask[i++] = 'l';
  smask[i] = '\0';
  return smask;
}


static int db_sethook (ell_State *L) {
  int arg, mask, count;
  ell_Hook func;
  ell_State *L1 = getthread(L, &arg);
  if (ell_isnoneornil(L, arg+1)) {
    ell_settop(L, arg+1);
    func = NULL; mask = 0; count = 0;  /* turn off hooks */
  }
  else {
    const char *smask = ellL_checkstring(L, arg+2);
    ellL_checktype(L, arg+1, ELL_TFUNCTION);
    count = ellL_optint(L, arg+3, 0);
    func = hookf; mask = makemask(smask, count);
  }
  if (gethooktable(L) == 0) {  /* creating hook table? */
    ell_pushstring(L, "k");
    ell_setfield(L, -2, "__mode");  /** hooktable.__mode = "k" */
    ell_pushvalue(L, -1);
    ell_setmetatable(L, -2);  /* setmetatable(hooktable) = hooktable */
  }
  ell_pushthread(L1); ell_xmove(L1, L, 1);
  ell_pushvalue(L, arg+1);
  ell_rawset(L, -3);  /* set new hook */
  ell_sethook(L1, func, mask, count);  /* set hooks */
  return 0;
}


static int db_gethook (ell_State *L) {
  int arg;
  ell_State *L1 = getthread(L, &arg);
  char buff[5];
  int mask = ell_gethookmask(L1);
  ell_Hook hook = ell_gethook(L1);
  if (hook != NULL && hook != hookf)  /* external hook? */
    ell_pushliteral(L, "external hook");
  else {
    gethooktable(L);
    ell_pushthread(L1); ell_xmove(L1, L, 1);
    ell_rawget(L, -2);   /* get hook */
    ell_remove(L, -2);  /* remove hook table */
  }
  ell_pushstring(L, unmakemask(mask, buff));
  ell_pushinteger(L, ell_gethookcount(L1));
  return 3;
}


static int db_debug (ell_State *L) {
  for (;;) {
    char buffer[250];
    elli_writestringerror("%s", "ell_debug> ");
    if (fgets(buffer, sizeof(buffer), stdin) == 0 ||
        strcmp(buffer, "cont\n") == 0)
      return 0;
    if (ellL_loadbuffer(L, buffer, strlen(buffer), "=(debug command)") ||
        ell_pcall(L, 0, 0, 0))
      elli_writestringerror("%s\n", ell_tostring(L, -1));
    ell_settop(L, 0);  /* remove eventual returns */
  }
}


static int db_traceback (ell_State *L) {
  int arg;
  ell_State *L1 = getthread(L, &arg);
  const char *msg = ell_tostring(L, arg + 1);
  if (msg == NULL && !ell_isnoneornil(L, arg + 1))  /* non-string 'msg'? */
    ell_pushvalue(L, arg + 1);  /* return it untouched */
  else {
    int level = ellL_optint(L, arg + 2, (L == L1) ? 1 : 0);
    ellL_traceback(L, L1, msg, level);
  }
  return 1;
}


static const ellL_Reg dblib[] = {
  {"debug", db_debug},
  {"getuservalue", db_getuservalue},
  {"gethook", db_gethook},
  {"getinfo", db_getinfo},
  {"getlocal", db_getlocal},
  {"getregistry", db_getregistry},
  {"getmetatable", db_getmetatable},
  {"getupvalue", db_getupvalue},
  {"upvaluejoin", db_upvaluejoin},
  {"upvalueid", db_upvalueid},
  {"setuservalue", db_setuservalue},
  {"sethook", db_sethook},
  {"setlocal", db_setlocal},
  {"setmetatable", db_setmetatable},
  {"setupvalue", db_setupvalue},
  {"traceback", db_traceback},
  {NULL, NULL}
};


ELLMOD_API int ellopen_debug (ell_State *L) {
  ellL_newlib(L, dblib);
  return 1;
}

