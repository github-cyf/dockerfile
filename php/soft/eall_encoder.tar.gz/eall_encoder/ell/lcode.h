/*
** $Id: lcode.h,v 1.58.1.1 2013/04/12 18:48:47 roberto Exp $
** Code generator for Ell
** See Copyright Notice in ell.h
*/

#ifndef lcode_h
#define lcode_h

#include "llex.h"
#include "lobject.h"
#include "lopcodes.h"
#include "lparser.h"


/*
** Marks the end of a patch list. It is an invalid value both as an absolute
** address, and as a list link (would link an element to itself).
*/
#define NO_JUMP (-1)


/*
** grep "ORDER OPR" if you change these enums  (ORDER OP)
*/
typedef enum BinOpr {
  OPR_POW, OPR_DIV, OPR_ADD, OPR_MOD, OPR_SUB, OPR_MUL,
  OPR_CONCAT,
  // OPR_EQ, OPR_LT, OPR_LE,
  OPR_LE, OPR_LT, OPR_EQ,
  OPR_GT, OPR_GE, OPR_NE,
  OPR_OR, OPR_AND,
  OPR_NOBINOPR
} BinOpr;


typedef enum UnOpr { OPR_MINUS, OPR_NOT, OPR_LEN, OPR_NOUNOPR } UnOpr;


#define getcode(fs,e)	((fs)->f->code[(e)->u.info])

#define ellK_codeAsBx(fs,o,A,sBx)	ellK_codeABx(fs,o,A,(sBx)+MAXARG_sBx)

#define ellK_setmultret(fs,e)	ellK_setreturns(fs, e, ELL_MULTRET)

#define ellK_jumpto(fs,t)	ellK_patchlist(fs, ellK_jump(fs), t)

ELLI_FUNC int ellK_codeABx (FuncState *fs, OpCode o, int A, unsigned int Bx);
ELLI_FUNC int ellK_codeABC (FuncState *fs, OpCode o, int A, int B, int C);
ELLI_FUNC int ellK_codek (FuncState *fs, int reg, int k);
ELLI_FUNC void ellK_fixline (FuncState *fs, int line);
ELLI_FUNC void ellK_nil (FuncState *fs, int from, int n);
ELLI_FUNC void ellK_reserveregs (FuncState *fs, int n);
ELLI_FUNC void ellK_checkstack (FuncState *fs, int n);
ELLI_FUNC int ellK_stringK (FuncState *fs, TString *s);
ELLI_FUNC int ellK_numberK (FuncState *fs, ell_Number r);
ELLI_FUNC void ellK_dischargevars (FuncState *fs, expdesc *e);
ELLI_FUNC int ellK_exp2anyreg (FuncState *fs, expdesc *e);
ELLI_FUNC void ellK_exp2anyregup (FuncState *fs, expdesc *e);
ELLI_FUNC void ellK_exp2nextreg (FuncState *fs, expdesc *e);
ELLI_FUNC void ellK_exp2val (FuncState *fs, expdesc *e);
ELLI_FUNC int ellK_exp2RK (FuncState *fs, expdesc *e);
ELLI_FUNC void ellK_self (FuncState *fs, expdesc *e, expdesc *key);
ELLI_FUNC void ellK_indexed (FuncState *fs, expdesc *t, expdesc *k);
ELLI_FUNC void ellK_goiftrue (FuncState *fs, expdesc *e);
ELLI_FUNC void ellK_goiffalse (FuncState *fs, expdesc *e);
ELLI_FUNC void ellK_storevar (FuncState *fs, expdesc *var, expdesc *e);
ELLI_FUNC void ellK_setreturns (FuncState *fs, expdesc *e, int nresults);
ELLI_FUNC void ellK_setoneret (FuncState *fs, expdesc *e);
ELLI_FUNC int ellK_jump (FuncState *fs);
ELLI_FUNC void ellK_ret (FuncState *fs, int first, int nret);
ELLI_FUNC void ellK_patchlist (FuncState *fs, int list, int target);
ELLI_FUNC void ellK_patchtohere (FuncState *fs, int list);
ELLI_FUNC void ellK_patchclose (FuncState *fs, int list, int level);
ELLI_FUNC void ellK_concat (FuncState *fs, int *l1, int l2);
ELLI_FUNC int ellK_getlabel (FuncState *fs);
ELLI_FUNC void ellK_prefix (FuncState *fs, UnOpr op, expdesc *v, int line);
ELLI_FUNC void ellK_infix (FuncState *fs, BinOpr op, expdesc *v);
ELLI_FUNC void ellK_posfix (FuncState *fs, BinOpr op, expdesc *v1,
                            expdesc *v2, int line);
ELLI_FUNC void ellK_setlist (FuncState *fs, int base, int nelems, int tostore);


#endif
