/*
** $Id: ell.h,v 1.285.1.2 2013/11/11 12:09:16 roberto Exp $
** Ell - A Scripting Language
** Ell.org, PUC-Rio, Brazil (http://www.ell.org)
** See Copyright Notice at the end of this file
*/


#ifndef ell_h
#define ell_h

#include <stdarg.h>
#include <stddef.h>


#include "ellconf.h"


#define ELL_VERSION_MAJOR	"0"
#define ELL_VERSION_MINOR	"0"
#define ELL_VERSION_NUM		001
#define ELL_VERSION_RELEASE	"1"

#define ELL_VERSION	"Ell " ELL_VERSION_MAJOR "." ELL_VERSION_MINOR
#define ELL_RELEASE	ELL_VERSION "." ELL_VERSION_RELEASE
#define ELL_COPYRIGHT	ELL_RELEASE "  Copyright (C) 2013-2014 eallcn.com, all rights reserved."
#define ELL_AUTHORS	"Modified by RemRain"


/* mark for precompiled code ('<esc>Ell') */
#define ELL_SIGNATURE	"\033Ell"

/* option for multiple returns in 'ell_pcall' and 'ell_call' */
#define ELL_MULTRET	(-1)


/*
** pseudo-indices
*/
#define ELL_REGISTRYINDEX	ELLI_FIRSTPSEUDOIDX
#define ell_upvalueindex(i)	(ELL_REGISTRYINDEX - (i))


/* thread status */
#define ELL_OK		0
#define ELL_YIELD	1
#define ELL_ERRRUN	2
#define ELL_ERRSYNTAX	3
#define ELL_ERRMEM	4
#define ELL_ERRGCMM	5
#define ELL_ERRERR	6


typedef struct ell_State ell_State;

typedef int (*ell_CFunction) (ell_State *L);


/*
** functions that read/write blocks when loading/dumping Ell chunks
*/
typedef const char * (*ell_Reader) (ell_State *L, void *ud, size_t *sz);

typedef int (*ell_Writer) (ell_State *L, const void* p, size_t sz, void* ud);


/*
** prototype for memory-allocation functions
*/
typedef void * (*ell_Alloc) (void *ud, void *ptr, size_t osize, size_t nsize);


/*
** basic types
*/
#define ELL_TNONE		(-1)

#define ELL_TNIL		0
#define ELL_TBOOLEAN		1
#define ELL_TLIGHTUSERDATA	2
#define ELL_TNUMBER		3
#define ELL_TSTRING		4
#define ELL_TTABLE		5
#define ELL_TFUNCTION		6
#define ELL_TUSERDATA		7
#define ELL_TTHREAD		8

#define ELL_NUMTAGS		9



/* minimum Ell stack available to a C function */
#define ELL_MINSTACK	20


/* predefined values in the registry */
#define ELL_RIDX_MAINTHREAD	1
#define ELL_RIDX_GLOBALS	2
#define ELL_RIDX_LAST		ELL_RIDX_GLOBALS


/* type of numbers in Ell */
typedef ELL_NUMBER ell_Number;


/* type for integer functions */
typedef ELL_INTEGER ell_Integer;

/* unsigned integer type */
typedef ELL_UNSIGNED ell_Unsigned;



/*
** generic extra include file
*/
#if defined(ELL_USER_H)
#include ELL_USER_H
#endif


/*
** RCS ident string
*/
extern const char ell_ident[];


/*
** state manipulation
*/
ELL_API ell_State *(ell_newstate) (ell_Alloc f, void *ud);
ELL_API void       (ell_close) (ell_State *L);
ELL_API ell_State *(ell_newthread) (ell_State *L);

ELL_API ell_CFunction (ell_atpanic) (ell_State *L, ell_CFunction panicf);


ELL_API const ell_Number *(ell_version) (ell_State *L);


/*
** basic stack manipulation
*/
ELL_API int   (ell_absindex) (ell_State *L, int idx);
ELL_API int   (ell_gettop) (ell_State *L);
ELL_API void  (ell_settop) (ell_State *L, int idx);
ELL_API void  (ell_pushvalue) (ell_State *L, int idx);
ELL_API void  (ell_remove) (ell_State *L, int idx);
ELL_API void  (ell_insert) (ell_State *L, int idx);
ELL_API void  (ell_replace) (ell_State *L, int idx);
ELL_API void  (ell_copy) (ell_State *L, int fromidx, int toidx);
ELL_API int   (ell_checkstack) (ell_State *L, int sz);

ELL_API void  (ell_xmove) (ell_State *from, ell_State *to, int n);


/*
** access functions (stack -> C)
*/

ELL_API int             (ell_isnumber) (ell_State *L, int idx);
ELL_API int             (ell_isstring) (ell_State *L, int idx);
ELL_API int             (ell_iscfunction) (ell_State *L, int idx);
ELL_API int             (ell_isuserdata) (ell_State *L, int idx);
ELL_API int             (ell_type) (ell_State *L, int idx);
ELL_API const char     *(ell_typename) (ell_State *L, int tp);

ELL_API ell_Number      (ell_tonumberx) (ell_State *L, int idx, int *isnum);
ELL_API ell_Integer     (ell_tointegerx) (ell_State *L, int idx, int *isnum);
ELL_API ell_Unsigned    (ell_tounsignedx) (ell_State *L, int idx, int *isnum);
ELL_API int             (ell_toboolean) (ell_State *L, int idx);
ELL_API const char     *(ell_tolstring) (ell_State *L, int idx, size_t *len);
ELL_API size_t          (ell_rawlen) (ell_State *L, int idx);
ELL_API ell_CFunction   (ell_tocfunction) (ell_State *L, int idx);
ELL_API void	       *(ell_touserdata) (ell_State *L, int idx);
ELL_API ell_State      *(ell_tothread) (ell_State *L, int idx);
ELL_API const void     *(ell_topointer) (ell_State *L, int idx);


/*
** Comparison and arithmetic functions
*/

#define ELL_OPDIV	0
#define ELL_OPPOW	1
#define ELL_OPADD	2	/* ORDER TM */
#define ELL_OPMOD	3
#define ELL_OPSUB	4
#define ELL_OPMUL	5
#define ELL_OPUNM	6

ELL_API void  (ell_arith) (ell_State *L, int op);

#define ELL_OPEQ	0
#define ELL_OPLE	1
#define ELL_OPLT	2

ELL_API int   (ell_rawequal) (ell_State *L, int idx1, int idx2);
ELL_API int   (ell_compare) (ell_State *L, int idx1, int idx2, int op);


/*
** push functions (C -> stack)
*/
ELL_API void        (ell_pushnil) (ell_State *L);
ELL_API void        (ell_pushnumber) (ell_State *L, ell_Number n);
ELL_API void        (ell_pushinteger) (ell_State *L, ell_Integer n);
ELL_API void        (ell_pushunsigned) (ell_State *L, ell_Unsigned n);
ELL_API const char *(ell_pushlstring) (ell_State *L, const char *s, size_t l);
ELL_API const char *(ell_pushstring) (ell_State *L, const char *s);
ELL_API const char *(ell_pushvfstring) (ell_State *L, const char *fmt,
                                                      va_list argp);
ELL_API const char *(ell_pushfstring) (ell_State *L, const char *fmt, ...);
ELL_API void  (ell_pushcclosure) (ell_State *L, ell_CFunction fn, int n);
ELL_API void  (ell_pushboolean) (ell_State *L, int b);
ELL_API void  (ell_pushlightuserdata) (ell_State *L, void *p);
ELL_API int   (ell_pushthread) (ell_State *L);


/*
** get functions (Ell -> stack)
*/
ELL_API void  (ell_getglobal) (ell_State *L, const char *var);
ELL_API void  (ell_gettable) (ell_State *L, int idx);
ELL_API void  (ell_getfield) (ell_State *L, int idx, const char *k);
ELL_API void  (ell_rawget) (ell_State *L, int idx);
ELL_API void  (ell_rawgeti) (ell_State *L, int idx, int n);
ELL_API void  (ell_rawgetp) (ell_State *L, int idx, const void *p);
ELL_API void  (ell_createtable) (ell_State *L, int narr, int nrec);
ELL_API void *(ell_newuserdata) (ell_State *L, size_t sz);
ELL_API int   (ell_getmetatable) (ell_State *L, int objindex);
ELL_API void  (ell_getuservalue) (ell_State *L, int idx);


/*
** set functions (stack -> Ell)
*/
ELL_API void  (ell_setglobal) (ell_State *L, const char *var);
ELL_API void  (ell_settable) (ell_State *L, int idx);
ELL_API void  (ell_setfield) (ell_State *L, int idx, const char *k);
ELL_API void  (ell_rawset) (ell_State *L, int idx);
ELL_API void  (ell_rawseti) (ell_State *L, int idx, int n);
ELL_API void  (ell_rawsetp) (ell_State *L, int idx, const void *p);
ELL_API int   (ell_setmetatable) (ell_State *L, int objindex);
ELL_API void  (ell_setuservalue) (ell_State *L, int idx);


/*
** 'load' and 'call' functions (load and run Ell code)
*/
ELL_API void  (ell_callk) (ell_State *L, int nargs, int nresults, int ctx,
                           ell_CFunction k);
#define ell_call(L,n,r)		ell_callk(L, (n), (r), 0, NULL)

ELL_API int   (ell_getctx) (ell_State *L, int *ctx);

ELL_API int   (ell_pcallk) (ell_State *L, int nargs, int nresults, int errfunc,
                            int ctx, ell_CFunction k);
#define ell_pcall(L,n,r,f)	ell_pcallk(L, (n), (r), (f), 0, NULL)

ELL_API int   (ell_load) (ell_State *L, ell_Reader reader, void *dt,
                                        const char *chunkname,
                                        const char *mode);

ELL_API int (ell_dump) (ell_State *L, ell_Writer writer, void *data);


/*
** coroutine functions
*/
ELL_API int  (ell_yieldk) (ell_State *L, int nresults, int ctx,
                           ell_CFunction k);
#define ell_yield(L,n)		ell_yieldk(L, (n), 0, NULL)
ELL_API int  (ell_resume) (ell_State *L, ell_State *from, int narg);
ELL_API int  (ell_status) (ell_State *L);

/*
** garbage-collection function and options
*/

#define ELL_GCSTOP		0
#define ELL_GCRESTART		1
#define ELL_GCCOLLECT		2
#define ELL_GCCOUNT		3
#define ELL_GCCOUNTB		4
#define ELL_GCSTEP		5
#define ELL_GCSETPAUSE		6
#define ELL_GCSETSTEPMUL	7
#define ELL_GCSETMAJORINC	8
#define ELL_GCISRUNNING		9
#define ELL_GCGEN		10
#define ELL_GCINC		11

ELL_API int (ell_gc) (ell_State *L, int what, int data);


/*
** miscellaneous functions
*/

ELL_API int   (ell_error) (ell_State *L);

ELL_API int   (ell_next) (ell_State *L, int idx);

ELL_API void  (ell_concat) (ell_State *L, int n);
ELL_API void  (ell_len)    (ell_State *L, int idx);

ELL_API ell_Alloc (ell_getallocf) (ell_State *L, void **ud);
ELL_API void      (ell_setallocf) (ell_State *L, ell_Alloc f, void *ud);



/*
** ===============================================================
** some useful macros
** ===============================================================
*/

#define ell_tonumber(L,i)	ell_tonumberx(L,i,NULL)
#define ell_tointeger(L,i)	ell_tointegerx(L,i,NULL)
#define ell_tounsigned(L,i)	ell_tounsignedx(L,i,NULL)

#define ell_pop(L,n)		ell_settop(L, -(n)-1)

#define ell_newtable(L)		ell_createtable(L, 0, 0)

#define ell_register(L,n,f) (ell_pushcfunction(L, (f)), ell_setglobal(L, (n)))

#define ell_pushcfunction(L,f)	ell_pushcclosure(L, (f), 0)

#define ell_isfunction(L,n)	(ell_type(L, (n)) == ELL_TFUNCTION)
#define ell_istable(L,n)	(ell_type(L, (n)) == ELL_TTABLE)
#define ell_islightuserdata(L,n)	(ell_type(L, (n)) == ELL_TLIGHTUSERDATA)
#define ell_isnil(L,n)		(ell_type(L, (n)) == ELL_TNIL)
#define ell_isboolean(L,n)	(ell_type(L, (n)) == ELL_TBOOLEAN)
#define ell_isthread(L,n)	(ell_type(L, (n)) == ELL_TTHREAD)
#define ell_isnone(L,n)		(ell_type(L, (n)) == ELL_TNONE)
#define ell_isnoneornil(L, n)	(ell_type(L, (n)) <= 0)

#define ell_pushliteral(L, s)	\
	ell_pushlstring(L, "" s, (sizeof(s)/sizeof(char))-1)

#define ell_pushglobaltable(L)  \
	ell_rawgeti(L, ELL_REGISTRYINDEX, ELL_RIDX_GLOBALS)

#define ell_tostring(L,i)	ell_tolstring(L, (i), NULL)



/*
** {======================================================================
** Debug API
** =======================================================================
*/


/*
** Event codes
*/
#define ELL_HOOKCALL	0
#define ELL_HOOKRET	1
#define ELL_HOOKLINE	2
#define ELL_HOOKCOUNT	3
#define ELL_HOOKTAILCALL 4


/*
** Event masks
*/
#define ELL_MASKCALL	(1 << ELL_HOOKCALL)
#define ELL_MASKRET	(1 << ELL_HOOKRET)
#define ELL_MASKLINE	(1 << ELL_HOOKLINE)
#define ELL_MASKCOUNT	(1 << ELL_HOOKCOUNT)

typedef struct ell_Debug ell_Debug;  /* activation record */


/* Functions to be called by the debugger in specific events */
typedef void (*ell_Hook) (ell_State *L, ell_Debug *ar);


ELL_API int (ell_getstack) (ell_State *L, int level, ell_Debug *ar);
ELL_API int (ell_getinfo) (ell_State *L, const char *what, ell_Debug *ar);
ELL_API const char *(ell_getlocal) (ell_State *L, const ell_Debug *ar, int n);
ELL_API const char *(ell_setlocal) (ell_State *L, const ell_Debug *ar, int n);
ELL_API const char *(ell_getupvalue) (ell_State *L, int funcindex, int n);
ELL_API const char *(ell_setupvalue) (ell_State *L, int funcindex, int n);

ELL_API void *(ell_upvalueid) (ell_State *L, int fidx, int n);
ELL_API void  (ell_upvaluejoin) (ell_State *L, int fidx1, int n1,
                                               int fidx2, int n2);

ELL_API int (ell_sethook) (ell_State *L, ell_Hook func, int mask, int count);
ELL_API ell_Hook (ell_gethook) (ell_State *L);
ELL_API int (ell_gethookmask) (ell_State *L);
ELL_API int (ell_gethookcount) (ell_State *L);


struct ell_Debug {
  int event;
  const char *name;	/* (n) */
  const char *namewhat;	/* (n) 'global', 'local', 'field', 'method' */
  const char *what;	/* (S) 'Ell', 'C', 'main', 'tail' */
  const char *source;	/* (S) */
  int currentline;	/* (l) */
  int linedefined;	/* (S) */
  int lastlinedefined;	/* (S) */
  unsigned char nups;	/* (u) number of upvalues */
  unsigned char nparams;/* (u) number of parameters */
  char isvararg;        /* (u) */
  char istailcall;	/* (t) */
  char short_src[ELL_IDSIZE]; /* (S) */
  /* private part */
  struct CallInfo *i_ci;  /* active function */
};

/* }====================================================================== */


/******************************************************************************
* Copyright (C) 1994-2013 Ell.org, PUC-Rio.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
******************************************************************************/


#endif
