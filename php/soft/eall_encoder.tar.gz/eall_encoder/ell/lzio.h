/*
** $Id: lzio.h,v 1.26.1.1 2013/04/12 18:48:47 roberto Exp $
** Buffered streams
** See Copyright Notice in ell.h
*/


#ifndef lzio_h
#define lzio_h

#include "ell.h"

#include "lmem.h"


#define EOZ	(-1)			/* end of stream */

typedef struct Zio ZIO;

#define zgetc(z)  (((z)->n--)>0 ?  cast_uchar(*(z)->p++) : ellZ_fill(z))


typedef struct Mbuffer {
  char *buffer;
  size_t n;
  size_t buffsize;
} Mbuffer;

#define ellZ_initbuffer(L, buff) ((buff)->buffer = NULL, (buff)->buffsize = 0)

#define ellZ_buffer(buff)	((buff)->buffer)
#define ellZ_sizebuffer(buff)	((buff)->buffsize)
#define ellZ_bufflen(buff)	((buff)->n)

#define ellZ_resetbuffer(buff) ((buff)->n = 0)


#define ellZ_resizebuffer(L, buff, size) \
	(ellM_reallocvector(L, (buff)->buffer, (buff)->buffsize, size, char), \
	(buff)->buffsize = size)

#define ellZ_freebuffer(L, buff)	ellZ_resizebuffer(L, buff, 0)


ELLI_FUNC char *ellZ_openspace (ell_State *L, Mbuffer *buff, size_t n);
ELLI_FUNC void ellZ_init (ell_State *L, ZIO *z, ell_Reader reader,
                                        void *data);
ELLI_FUNC size_t ellZ_read (ZIO* z, void* b, size_t n);	/* read next n bytes */



/* --------- Private Part ------------------ */

struct Zio {
  size_t n;			/* bytes still unread */
  const char *p;		/* current position in buffer */
  ell_Reader reader;		/* reader function */
  void* data;			/* additional data */
  ell_State *L;			/* Ell state (for reader) */
};


ELLI_FUNC int ellZ_fill (ZIO *z);

#endif
