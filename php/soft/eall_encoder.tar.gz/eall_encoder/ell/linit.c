/*
** $Id: linit.c,v 1.32.1.1 2013/04/12 18:48:47 roberto Exp $
** Initialization of libraries for ell.c and other clients
** See Copyright Notice in ell.h
*/


/*
** If you embed Ell in your program and need to open the standard
** libraries, call ellL_openlibs in your program. If you need a
** different set of libraries, copy this file to your project and edit
** it to suit your needs.
*/


#define linit_c
#define ELL_LIB

#include "ell.h"

#include "elllib.h"
#include "lauxlib.h"


/*
** these libs are loaded by ell.c and are readily available to any Ell
** program
*/
static const ellL_Reg loadedlibs[] = {
  {"_G", ellopen_base},
  {ELL_LOADLIBNAME, ellopen_package},
  // {ELL_COLIBNAME, ellopen_coroutine},
  {ELL_TABLIBNAME, ellopen_table},
  {ELL_IOLIBNAME, ellopen_io},
  {ELL_OSLIBNAME, ellopen_os},
  {ELL_STRLIBNAME, ellopen_string},
  {ELL_BITLIBNAME, ellopen_bit32},
  // {ELL_DBLIBNAME, ellopen_debug},
  {NULL, NULL}
};


/*
** these libs are preloaded and must be required before used
*/
static const ellL_Reg preloadedlibs[] = {
  {NULL, NULL}
};


ELLLIB_API void ellL_openlibs (ell_State *L) {
  const ellL_Reg *lib;
  /* call open functions from 'loadedlibs' and set results to global table */
  for (lib = loadedlibs; lib->func; lib++) {
    ellL_requiref(L, lib->name, lib->func, 1);
    ell_pop(L, 1);  /* remove lib */
  }
  /* add open functions from 'preloadedlibs' into 'package.preload' table */
  ellL_getsubtable(L, ELL_REGISTRYINDEX, "_PRELOAD");
  for (lib = preloadedlibs; lib->func; lib++) {
    ell_pushcfunction(L, lib->func);
    ell_setfield(L, -2, lib->name);
  }
  ell_pop(L, 1);  /* remove _PRELOAD table */
}

