/*
** $Id: ellconf.h,v 1.176.1.1 2013/04/12 18:48:47 roberto Exp $
** Configuration file for Ell
** See Copyright Notice in ell.h
*/


#ifndef lconfig_h
#define lconfig_h

#include <limits.h>
#include <stddef.h>


/*
** ==================================================================
** Search for "@@" to find all configurable definitions.
** ===================================================================
*/


/*
@@ ELL_ANSI controls the use of non-ansi features.
** CHANGE it (define it) if you want Ell to avoid the use of any
** non-ansi feature or library.
*/
#if !defined(ELL_ANSI) && defined(__STRICT_ANSI__)
#define ELL_ANSI
#endif


#if !defined(ELL_ANSI) && defined(_WIN32) && !defined(_WIN32_WCE)
#define ELL_WIN		/* enable goodies for regular Windows platforms */
#endif

#if defined(ELL_WIN)
#define ELL_DL_DLL
#define ELL_USE_AFORMAT		/* assume 'printf' handles 'aA' specifiers */
#endif



#if defined(ELL_USE_LINUX)
#define ELL_USE_POSIX
#define ELL_USE_DLOPEN		/* needs an extra library: -ldl */
#define ELL_USE_READLINE	/* needs some extra libraries */
#define ELL_USE_STRTODHEX	/* assume 'strtod' handles hex formats */
#define ELL_USE_AFORMAT		/* assume 'printf' handles 'aA' specifiers */
#define ELL_USE_LONGLONG	/* assume support for long long */
#endif

#if defined(ELL_USE_MACOSX)
#define ELL_USE_POSIX
#define ELL_USE_DLOPEN		/* does not need -ldl */
#define ELL_USE_READLINE	/* needs an extra library: -lreadline */
#define ELL_USE_STRTODHEX	/* assume 'strtod' handles hex formats */
#define ELL_USE_AFORMAT		/* assume 'printf' handles 'aA' specifiers */
#define ELL_USE_LONGLONG	/* assume support for long long */
#endif



/*
@@ ELL_USE_POSIX includes all functionality listed as X/Open System
@* Interfaces Extension (XSI).
** CHANGE it (define it) if your system is XSI compatible.
*/
#if defined(ELL_USE_POSIX)
#define ELL_USE_MKSTEMP
#define ELL_USE_ISATTY
#define ELL_USE_POPEN
#define ELL_USE_ULONGJMP
#define ELL_USE_GMTIME_R
#endif



/*
@@ ELL_PATH_DEFAULT is the default path that Ell uses to look for
@* Ell libraries.
@@ ELL_CPATH_DEFAULT is the default path that Ell uses to look for
@* C libraries.
** CHANGE them if your machine has a non-conventional directory
** hierarchy or if you want to install your libraries in
** non-conventional directories.
*/
#if defined(_WIN32)	/* { */
/*
** In Windows, any exclamation mark ('!') in the path is replaced by the
** path of the directory of the executable file of the current process.
*/
#define ELL_LDIR	"!\\ell\\"
#define ELL_CDIR	"!\\"
#define ELL_PATH_DEFAULT  \
		ELL_LDIR"?.ell;"  ELL_LDIR"?\\init.ell;" \
		ELL_CDIR"?.ell;"  ELL_CDIR"?\\init.ell;" ".\\?.ell"
#define ELL_CPATH_DEFAULT \
		ELL_CDIR"?.dll;" ELL_CDIR"loadall.dll;" ".\\?.dll"

#else			/* }{ */

#define ELL_VDIR	ELL_VERSION_MAJOR "." ELL_VERSION_MINOR "/"
#define ELL_ROOT	"/usr/local/"
#define ELL_LDIR	ELL_ROOT "share/ell/" ELL_VDIR
#define ELL_CDIR	ELL_ROOT "lib/ell/" ELL_VDIR
#define ELL_PATH_DEFAULT  \
		ELL_LDIR"?.ell;"  ELL_LDIR"?/init.ell;" \
		ELL_CDIR"?.ell;"  ELL_CDIR"?/init.ell;" "./?.ell"
#define ELL_CPATH_DEFAULT \
		ELL_CDIR"?.so;" ELL_CDIR"loadall.so;" "./?.so"
#endif			/* } */


/*
@@ ELL_DIRSEP is the directory separator (for submodules).
** CHANGE it if your machine does not use "/" as the directory separator
** and is not Windows. (On Windows Ell automatically uses "\".)
*/
#if defined(_WIN32)
#define ELL_DIRSEP	"\\"
#else
#define ELL_DIRSEP	"/"
#endif


/*
@@ ELL_ENV is the name of the variable that holds the current
@@ environment, used to access global names.
** CHANGE it if you do not like this name.
*/
#define ELL_ENV		"_GLOBALE"


/*
@@ ELL_API is a mark for all core API functions.
@@ ELLLIB_API is a mark for all auxiliary library functions.
@@ ELLMOD_API is a mark for all standard library opening functions.
** CHANGE them if you need to define those functions in some special way.
** For instance, if you want to create one Windows DLL with the core and
** the libraries, you may want to use the following definition (define
** ELL_BUILD_AS_DLL to get it).
*/
#if defined(ELL_BUILD_AS_DLL)	/* { */

#if defined(ELL_CORE) || defined(ELL_LIB)	/* { */
#define ELL_API __declspec(dllexport)
#else						/* }{ */
#define ELL_API __declspec(dllimport)
#endif						/* } */

#else				/* }{ */

#define ELL_API		extern

#endif				/* } */


/* more often than not the libs go together with the core */
#define ELLLIB_API	ELL_API
#define ELLMOD_API	ELLLIB_API


/*
@@ ELLI_FUNC is a mark for all extern functions that are not to be
@* exported to outside modules.
@@ ELLI_DDEF and ELLI_DDEC are marks for all extern (const) variables
@* that are not to be exported to outside modules (ELLI_DDEF for
@* definitions and ELLI_DDEC for declarations).
** CHANGE them if you need to mark them in some special way. Elf/gcc
** (versions 3.2 and later) mark them as "hidden" to optimize access
** when Ell is compiled as a shared library. Not all elf targets support
** this attribute. Unfortunately, gcc does not offer a way to check
** whether the target offers that support, and those without support
** give a warning about it. To avoid these warnings, change to the
** default definition.
*/
#if defined(__GNUC__) && ((__GNUC__*100 + __GNUC_MINOR__) >= 302) && \
    defined(__ELF__)		/* { */
#define ELLI_FUNC	__attribute__((visibility("hidden"))) extern
#define ELLI_DDEC	ELLI_FUNC
#define ELLI_DDEF	/* empty */

#else				/* }{ */
#define ELLI_FUNC	extern
#define ELLI_DDEC	extern
#define ELLI_DDEF	/* empty */
#endif				/* } */



/*
@@ ELL_QL describes how error messages quote program elements.
** CHANGE it if you want a different appearance.
*/
#define ELL_QL(x)	"'" x "'"
#define ELL_QS		ELL_QL("%s")


/*
@@ ELL_IDSIZE gives the maximum size for the description of the source
@* of a function in debug information.
** CHANGE it if you want a different size.
*/
#define ELL_IDSIZE	60


/*
@@ elli_writestring/elli_writeline define how 'print' prints its results.
** They are only used in libraries and the stand-alone program. (The #if
** avoids including 'stdio.h' everywhere.)
*/
#if defined(ELL_LIB) || defined(ell_c)
#include <stdio.h>
#define elli_writestring(s,l)	fwrite((s), sizeof(char), (l), stdout)
#define elli_writeline()	(elli_writestring("\n", 1), fflush(stdout))
#endif

/*
@@ elli_writestringerror defines how to print error messages.
** (A format string with one argument is enough for Ell...)
*/
#define elli_writestringerror(s,p) \
	(fprintf(stderr, (s), (p)), fflush(stderr))


/*
@@ ELLI_MAXSHORTLEN is the maximum length for short strings, that is,
** strings that are internalized. (Cannot be smaller than reserved words
** or tags for metamethods, as these strings must be internalized;
** #("function") = 8, #("__newindex") = 10.)
*/
#define ELLI_MAXSHORTLEN        40



/*
** {==================================================================
** Compatibility with previous versions
** ===================================================================
*/

/*
@@ ELL_COMPAT_ALL controls all compatibility options.
** You can define it to get all options, or change specific options
** to fit your specific needs.
*/
#if defined(ELL_COMPAT_ALL)	/* { */

/*
@@ ELL_COMPAT_UNPACK controls the presence of global 'unpack'.
** You can replace it with 'table.unpack'.
*/
#define ELL_COMPAT_UNPACK

/*
@@ ELL_COMPAT_LOADERS controls the presence of table 'package.loaders'.
** You can replace it with 'package.searchers'.
*/
#define ELL_COMPAT_LOADERS

/*
@@ macro 'ell_cpcall' emulates deprecated function ell_cpcall.
** You can call your C function directly (with light C functions).
*/
#define ell_cpcall(L,f,u)  \
	(ell_pushcfunction(L, (f)), \
	 ell_pushlightuserdata(L,(u)), \
	 ell_pcall(L,1,0,0))


/*
@@ ELL_COMPAT_LOG10 defines the function 'log10' in the math library.
** You can rewrite 'log10(x)' as 'log(x, 10)'.
*/
#define ELL_COMPAT_LOG10

/*
@@ ELL_COMPAT_LOADSTRING defines the function 'loadstring' in the base
** library. You can rewrite 'loadstring(s)' as 'load(s)'.
*/
#define ELL_COMPAT_LOADSTRING

/*
@@ ELL_COMPAT_MAXN defines the function 'maxn' in the table library.
*/
#define ELL_COMPAT_MAXN

/*
@@ The following macros supply trivial compatibility for some
** changes in the API. The macros themselves document how to
** change your code to avoid using them.
*/
#define ell_strlen(L,i)		ell_rawlen(L, (i))

#define ell_objlen(L,i)		ell_rawlen(L, (i))

#define ell_equal(L,idx1,idx2)		ell_compare(L,(idx1),(idx2),ELL_OPEQ)
#define ell_lessthan(L,idx1,idx2)	ell_compare(L,(idx1),(idx2),ELL_OPLT)

/*
@@ ELL_COMPAT_MODULE controls compatibility with previous
** module functions 'module' (Ell) and 'ellL_register' (C).
*/
#define ELL_COMPAT_MODULE

#endif				/* } */

/* }================================================================== */



/*
@@ ELLI_BITSINT defines the number of bits in an int.
** CHANGE here if Ell cannot automatically detect the number of bits of
** your machine. Probably you do not need to change this.
*/
/* avoid overflows in comparison */
#if INT_MAX-20 < 32760		/* { */
#define ELLI_BITSINT	16
#elif INT_MAX > 2147483640L	/* }{ */
/* int has at least 32 bits */
#define ELLI_BITSINT	32
#else				/* }{ */
#error "you must define ELL_BITSINT with number of bits in an integer"
#endif				/* } */


/*
@@ ELL_INT32 is an signed integer with exactly 32 bits.
@@ ELLI_UMEM is an unsigned integer big enough to count the total
@* memory used by Ell.
@@ ELLI_MEM is a signed integer big enough to count the total memory
@* used by Ell.
** CHANGE here if for some weird reason the default definitions are not
** good enough for your machine. Probably you do not need to change
** this.
*/
#if ELLI_BITSINT >= 32		/* { */
#define ELL_INT32	int
#define ELLI_UMEM	size_t
#define ELLI_MEM	ptrdiff_t
#else				/* }{ */
/* 16-bit ints */
#define ELL_INT32	long
#define ELLI_UMEM	unsigned long
#define ELLI_MEM	long
#endif				/* } */


/*
@@ ELLI_MAXSTACK limits the size of the Ell stack.
** CHANGE it if you need a different limit. This limit is arbitrary;
** its only purpose is to stop Ell to consume unlimited stack
** space (and to reserve some numbers for pseudo-indices).
*/
#if ELLI_BITSINT >= 32
#define ELLI_MAXSTACK		1000000
#else
#define ELLI_MAXSTACK		15000
#endif

/* reserve some space for error handling */
#define ELLI_FIRSTPSEUDOIDX	(-ELLI_MAXSTACK - 1000)




/*
@@ ELLL_BUFFERSIZE is the buffer size used by the lauxlib buffer system.
** CHANGE it if it uses too much C-stack space.
*/
#define ELLL_BUFFERSIZE		BUFSIZ




/*
** {==================================================================
@@ ELL_NUMBER is the type of numbers in Ell.
** CHANGE the following definitions only if you want to build Ell
** with a number type different from double. You may also need to
** change ell_number2int & ell_number2integer.
** ===================================================================
*/

#define ELL_NUMBER_DOUBLE
#define ELL_NUMBER	double

/*
@@ ELLI_UACNUMBER is the result of an 'usual argument conversion'
@* over a number.
*/
#define ELLI_UACNUMBER	double


/*
@@ ELL_NUMBER_SCAN is the format for reading numbers.
@@ ELL_NUMBER_FMT is the format for writing numbers.
@@ ell_number2str converts a number to a string.
@@ ELLI_MAXNUMBER2STR is maximum size of previous conversion.
*/
#define ELL_NUMBER_SCAN		"%lf"
#define ELL_NUMBER_FMT		"%.14g"
#define ell_number2str(s,n)	sprintf((s), ELL_NUMBER_FMT, (n))
#define ELLI_MAXNUMBER2STR	32 /* 16 digits, sign, point, and \0 */


/*
@@ l_mathop allows the addition of an 'l' or 'f' to all math operations
*/
#define l_mathop(x)		(x)


/*
@@ ell_str2number converts a decimal numeric string to a number.
@@ ell_strx2number converts an hexadecimal numeric string to a number.
** In C99, 'strtod' does both conversions. C89, however, has no function
** to convert floating hexadecimal strings to numbers. For these
** systems, you can leave 'ell_strx2number' undefined and Ell will
** provide its own implementation.
*/
#define ell_str2number(s,p)	strtod((s), (p))

#if defined(ELL_USE_STRTODHEX)
#define ell_strx2number(s,p)	strtod((s), (p))
#endif


/*
@@ The elli_num* macros define the primitive operations over numbers.
*/

/* the following operations need the math library */
#if defined(lobject_c) || defined(lvm_c)
#include <math.h>
#define elli_nummod(L,a,b)	((a) - l_mathop(floor)((a)/(b))*(b))
#define elli_numpow(L,a,b)	(l_mathop(pow)(a,b))
#endif

/* these are quite standard operations */
#if defined(ELL_CORE)
#define elli_numadd(L,a,b)	((a)+(b))
#define elli_numsub(L,a,b)	((a)-(b))
#define elli_nummul(L,a,b)	((a)*(b))
#define elli_numdiv(L,a,b)	((a)/(b))
#define elli_numunm(L,a)	(-(a))
#define elli_numeq(a,b)		((a)==(b))
#define elli_numlt(L,a,b)	((a)<(b))
#define elli_numle(L,a,b)	((a)<=(b))
#define elli_numisnan(L,a)	(!elli_numeq((a), (a)))
#endif



/*
@@ ELL_INTEGER is the integral type used by ell_pushinteger/ell_tointeger.
** CHANGE that if ptrdiff_t is not adequate on your machine. (On most
** machines, ptrdiff_t gives a good choice between int or long.)
*/
#define ELL_INTEGER	ptrdiff_t

/*
@@ ELL_UNSIGNED is the integral type used by ell_pushunsigned/ell_tounsigned.
** It must have at least 32 bits.
*/
#define ELL_UNSIGNED	unsigned ELL_INT32



/*
** Some tricks with doubles
*/

#if defined(ELL_NUMBER_DOUBLE) && !defined(ELL_ANSI)	/* { */
/*
** The next definitions activate some tricks to speed up the
** conversion from doubles to integer types, mainly to ELL_UNSIGNED.
**
@@ ELL_MSASMTRICK uses Microsoft assembler to avoid clashes with a
** DirectX idiosyncrasy.
**
@@ ELL_IEEE754TRICK uses a trick that should work on any machine
** using IEEE754 with a 32-bit integer type.
**
@@ ELL_IEEELL extends the trick to ELL_INTEGER; should only be
** defined when ELL_INTEGER is a 32-bit integer.
**
@@ ELL_IEEEENDIAN is the endianness of doubles in your machine
** (0 for little endian, 1 for big endian); if not defined, Ell will
** check it dynamically for ELL_IEEE754TRICK (but not for ELL_NANTRICK).
**
@@ ELL_NANTRICK controls the use of a trick to pack all types into
** a single double value, using NaN values to represent non-number
** values. The trick only works on 32-bit machines (ints and pointers
** are 32-bit values) with numbers represented as IEEE 754-2008 doubles
** with conventional endianess (12345678 or 87654321), in CPUs that do
** not produce signaling NaN values (all NaNs are quiet).
*/

/* Microsoft compiler on a Pentium (32 bit) ? */
#if defined(ELL_WIN) && defined(_MSC_VER) && defined(_M_IX86)	/* { */

#define ELL_MSASMTRICK
#define ELL_IEEEENDIAN		0
#define ELL_NANTRICK


/* pentium 32 bits? */
#elif defined(__i386__) || defined(__i386) || defined(__X86__) /* }{ */

#define ELL_IEEE754TRICK
#define ELL_IEEELL
#define ELL_IEEEENDIAN		0
#define ELL_NANTRICK

/* pentium 64 bits? */
#elif defined(__x86_64)						/* }{ */

#define ELL_IEEE754TRICK
#define ELL_IEEEENDIAN		0

#elif defined(__POWERPC__) || defined(__ppc__)			/* }{ */

#define ELL_IEEE754TRICK
#define ELL_IEEEENDIAN		1

#else								/* }{ */

/* assume IEEE754 and a 32-bit integer type */
#define ELL_IEEE754TRICK

#endif								/* } */

#endif							/* } */

/* }================================================================== */




/* =================================================================== */

/*
** Local configuration. You can use this space to add your redefinitions
** without modifying the main part of the file.
*/



#endif

