/*
** $Id: lfunc.h,v 2.8.1.1 2013/04/12 18:48:47 roberto Exp $
** Auxiliary functions to manipulate prototypes and closures
** See Copyright Notice in ell.h
*/

#ifndef lfunc_h
#define lfunc_h


#include "lobject.h"


#define sizeCclosure(n)	(cast(int, sizeof(CClosure)) + \
                         cast(int, sizeof(TValue)*((n)-1)))

#define sizeLclosure(n)	(cast(int, sizeof(LClosure)) + \
                         cast(int, sizeof(TValue *)*((n)-1)))


ELLI_FUNC Proto *ellF_newproto (ell_State *L);
ELLI_FUNC Closure *ellF_newCclosure (ell_State *L, int nelems);
ELLI_FUNC Closure *ellF_newLclosure (ell_State *L, int nelems);
ELLI_FUNC UpVal *ellF_newupval (ell_State *L);
ELLI_FUNC UpVal *ellF_findupval (ell_State *L, StkId level);
ELLI_FUNC void ellF_close (ell_State *L, StkId level);
ELLI_FUNC void ellF_freeproto (ell_State *L, Proto *f);
ELLI_FUNC void ellF_freeupval (ell_State *L, UpVal *uv);
ELLI_FUNC const char *ellF_getlocalname (const Proto *func, int local_number,
                                         int pc);


#endif
