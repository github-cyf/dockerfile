/*
** $Id: lcorolib.c,v 1.5.1.1 2013/04/12 18:48:47 roberto Exp $
** Coroutine Library
** See Copyright Notice in ell.h
*/


#include <stdlib.h>


#define lcorolib_c
#define ELL_LIB

#include "ell.h"

#include "lauxlib.h"
#include "elllib.h"


static int auxresume (ell_State *L, ell_State *co, int narg) {
  int status;
  if (!ell_checkstack(co, narg)) {
    ell_pushliteral(L, "too many arguments to resume");
    return -1;  /* error flag */
  }
  if (ell_status(co) == ELL_OK && ell_gettop(co) == 0) {
    ell_pushliteral(L, "cannot resume dead coroutine");
    return -1;  /* error flag */
  }
  ell_xmove(L, co, narg);
  status = ell_resume(co, L, narg);
  if (status == ELL_OK || status == ELL_YIELD) {
    int nres = ell_gettop(co);
    if (!ell_checkstack(L, nres + 1)) {
      ell_pop(co, nres);  /* remove results anyway */
      ell_pushliteral(L, "too many results to resume");
      return -1;  /* error flag */
    }
    ell_xmove(co, L, nres);  /* move yielded values */
    return nres;
  }
  else {
    ell_xmove(co, L, 1);  /* move error message */
    return -1;  /* error flag */
  }
}


static int ellB_coresume (ell_State *L) {
  ell_State *co = ell_tothread(L, 1);
  int r;
  ellL_argcheck(L, co, 1, "coroutine expected");
  r = auxresume(L, co, ell_gettop(L) - 1);
  if (r < 0) {
    ell_pushboolean(L, 0);
    ell_insert(L, -2);
    return 2;  /* return false + error message */
  }
  else {
    ell_pushboolean(L, 1);
    ell_insert(L, -(r + 1));
    return r + 1;  /* return true + `resume' returns */
  }
}


static int ellB_auxwrap (ell_State *L) {
  ell_State *co = ell_tothread(L, ell_upvalueindex(1));
  int r = auxresume(L, co, ell_gettop(L));
  if (r < 0) {
    if (ell_isstring(L, -1)) {  /* error object is a string? */
      ellL_where(L, 1);  /* add extra info */
      ell_insert(L, -2);
      ell_concat(L, 2);
    }
    return ell_error(L);  /* propagate error */
  }
  return r;
}


static int ellB_cocreate (ell_State *L) {
  ell_State *NL;
  ellL_checktype(L, 1, ELL_TFUNCTION);
  NL = ell_newthread(L);
  ell_pushvalue(L, 1);  /* move function to top */
  ell_xmove(L, NL, 1);  /* move function from L to NL */
  return 1;
}


static int ellB_cowrap (ell_State *L) {
  ellB_cocreate(L);
  ell_pushcclosure(L, ellB_auxwrap, 1);
  return 1;
}


static int ellB_yield (ell_State *L) {
  return ell_yield(L, ell_gettop(L));
}


static int ellB_costatus (ell_State *L) {
  ell_State *co = ell_tothread(L, 1);
  ellL_argcheck(L, co, 1, "coroutine expected");
  if (L == co) ell_pushliteral(L, "running");
  else {
    switch (ell_status(co)) {
      case ELL_YIELD:
        ell_pushliteral(L, "suspended");
        break;
      case ELL_OK: {
        ell_Debug ar;
        if (ell_getstack(co, 0, &ar) > 0)  /* does it have frames? */
          ell_pushliteral(L, "normal");  /* it is running */
        else if (ell_gettop(co) == 0)
            ell_pushliteral(L, "dead");
        else
          ell_pushliteral(L, "suspended");  /* initial state */
        break;
      }
      default:  /* some error occurred */
        ell_pushliteral(L, "dead");
        break;
    }
  }
  return 1;
}


static int ellB_corunning (ell_State *L) {
  int ismain = ell_pushthread(L);
  ell_pushboolean(L, ismain);
  return 2;
}


static const ellL_Reg co_funcs[] = {
  {"create", ellB_cocreate},
  {"resume", ellB_coresume},
  {"running", ellB_corunning},
  {"status", ellB_costatus},
  {"wrap", ellB_cowrap},
  {"yield", ellB_yield},
  {NULL, NULL}
};



ELLMOD_API int ellopen_coroutine (ell_State *L) {
  ellL_newlib(L, co_funcs);
  return 1;
}

