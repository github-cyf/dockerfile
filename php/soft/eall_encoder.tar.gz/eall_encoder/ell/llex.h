/*
** $Id: llex.h,v 1.72.1.1 2013/04/12 18:48:47 roberto Exp $
** Lexical Analyzer
** See Copyright Notice in ell.h
*/

#ifndef llex_h
#define llex_h

#include "lobject.h"
#include "lzio.h"


#define FIRST_RESERVED	257



/*
* WARNING: if you change the order of this enumeration,
* grep "ORDER RESERVED"
*/
enum RESERVED {
  /* terminal symbols denoted by reserved words */
  TK_AND = FIRST_RESERVED, TK_TRUE, TK_DO, TK_DBCOLON, TK_BREAK, TK_ELSE,
  TK_ELSEIF, TK_EQ, TK_END, TK_FALSE, TK_FOR, TK_FUNCTION, TK_GOTO, TK_IF,
  TK_IN, TK_NIL, TK_NOT, TK_OR, TK_REPEAT, TK_LOCAL,
  TK_UNTIL, TK_RETURN, TK_THEN, TK_WHILE,
  /* other terminal symbols */
  TK_NE, TK_CONCAT, TK_DOTS, TK_GE, TK_LE, TK_EOS,
  TK_NAME, TK_STRING, TK_NUMBER
};

/* number of reserved words */
#define NUM_RESERVED	(cast(int, TK_WHILE-FIRST_RESERVED+1))


typedef union {
  ell_Number r;
  TString *ts;
} SemInfo;  /* semantics information */


typedef struct Token {
  int token;
  SemInfo seminfo;
} Token;


/* state of the lexer plus state of the parser when shared by all
   functions */
typedef struct LexState {
  int current;  /* current character (charint) */
  int linenumber;  /* input line counter */
  int lastline;  /* line of last token `consumed' */
  Token t;  /* current token */
  Token lookahead;  /* look ahead token */
  struct FuncState *fs;  /* current function (parser) */
  struct ell_State *L;
  ZIO *z;  /* input stream */
  Mbuffer *buff;  /* buffer for tokens */
  struct Dyndata *dyd;  /* dynamic structures used by the parser */
  TString *source;  /* current source name */
  TString *envn;  /* environment variable name */
  char decpoint;  /* locale decimal point */
} LexState;


ELLI_FUNC void ellX_init (ell_State *L);
ELLI_FUNC void ellX_setinput (ell_State *L, LexState *ls, ZIO *z,
                              TString *source, int firstchar);
ELLI_FUNC TString *ellX_newstring (LexState *ls, const char *str, size_t l);
ELLI_FUNC void ellX_next (LexState *ls);
ELLI_FUNC int ellX_lookahead (LexState *ls);
ELLI_FUNC l_noret ellX_syntaxerror (LexState *ls, const char *s);
ELLI_FUNC const char *ellX_token2str (LexState *ls, int token);


#endif
