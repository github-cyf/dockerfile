/*
** $Id: ldo.h,v 2.20.1.1 2013/04/12 18:48:47 roberto Exp $
** Stack and Call structure of Ell
** See Copyright Notice in ell.h
*/

#ifndef ldo_h
#define ldo_h


#include "lobject.h"
#include "lstate.h"
#include "lzio.h"


#define ellD_checkstack(L,n)	if (L->stack_last - L->top <= (n)) \
				    ellD_growstack(L, n); else condmovestack(L);


#define incr_top(L) {L->top++; ellD_checkstack(L,0);}

#define savestack(L,p)		((char *)(p) - (char *)L->stack)
#define restorestack(L,n)	((TValue *)((char *)L->stack + (n)))


/* type of protected functions, to be ran by `runprotected' */
typedef void (*Pfunc) (ell_State *L, void *ud);

ELLI_FUNC int ellD_protectedparser (ell_State *L, ZIO *z, const char *name,
                                                  const char *mode);
ELLI_FUNC void ellD_hook (ell_State *L, int event, int line);
ELLI_FUNC int ellD_precall (ell_State *L, StkId func, int nresults);
ELLI_FUNC void ellD_call (ell_State *L, StkId func, int nResults,
                                        int allowyield);
ELLI_FUNC int ellD_pcall (ell_State *L, Pfunc func, void *u,
                                        ptrdiff_t oldtop, ptrdiff_t ef);
ELLI_FUNC int ellD_poscall (ell_State *L, StkId firstResult);
ELLI_FUNC void ellD_reallocstack (ell_State *L, int newsize);
ELLI_FUNC void ellD_growstack (ell_State *L, int n);
ELLI_FUNC void ellD_shrinkstack (ell_State *L);

ELLI_FUNC l_noret ellD_throw (ell_State *L, int errcode);
ELLI_FUNC int ellD_rawrunprotected (ell_State *L, Pfunc f, void *ud);

#endif

