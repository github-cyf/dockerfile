/*
** $Id: ltable.h,v 2.16.1.2 2013/08/30 15:49:41 roberto Exp $
** Ell tables (hash)
** See Copyright Notice in ell.h
*/

#ifndef ltable_h
#define ltable_h

#include "lobject.h"


#define gnode(t,i)	(&(t)->node[i])
#define gkey(n)		(&(n)->i_key.tvk)
#define gval(n)		(&(n)->i_val)
#define gnext(n)	((n)->i_key.nk.next)

#define invalidateTMcache(t)	((t)->flags = 0)

/* returns the key, given the value of a table entry */
#define keyfromval(v) \
  (gkey(cast(Node *, cast(char *, (v)) - offsetof(Node, i_val))))


ELLI_FUNC const TValue *ellH_getint (Table *t, int key);
ELLI_FUNC void ellH_setint (ell_State *L, Table *t, int key, TValue *value);
ELLI_FUNC const TValue *ellH_getstr (Table *t, TString *key);
ELLI_FUNC const TValue *ellH_get (Table *t, const TValue *key);
ELLI_FUNC TValue *ellH_newkey (ell_State *L, Table *t, const TValue *key);
ELLI_FUNC TValue *ellH_set (ell_State *L, Table *t, const TValue *key);
ELLI_FUNC Table *ellH_new (ell_State *L);
ELLI_FUNC void ellH_resize (ell_State *L, Table *t, int nasize, int nhsize);
ELLI_FUNC void ellH_resizearray (ell_State *L, Table *t, int nasize);
ELLI_FUNC void ellH_free (ell_State *L, Table *t);
ELLI_FUNC int ellH_next (ell_State *L, Table *t, StkId key);
ELLI_FUNC int ellH_getn (Table *t);


#if defined(ELL_DEBUG)
ELLI_FUNC Node *ellH_mainposition (const Table *t, const TValue *key);
ELLI_FUNC int ellH_isdummy (Node *n);
#endif


#endif
