/*
** $Id: lauxlib.h,v 1.120.1.1 2013/04/12 18:48:47 roberto Exp $
** Auxiliary functions for building Ell libraries
** See Copyright Notice in ell.h
*/


#ifndef lauxlib_h
#define lauxlib_h


#include <stddef.h>
#include <stdio.h>

#include "ell.h"



/* extra error code for `ellL_load' */
#define ELL_ERRFILE     (ELL_ERRERR+1)


typedef struct ellL_Reg {
  const char *name;
  ell_CFunction func;
} ellL_Reg;


ELLLIB_API void (ellL_checkversion_) (ell_State *L, ell_Number ver);
#define ellL_checkversion(L)	ellL_checkversion_(L, ELL_VERSION_NUM)

ELLLIB_API int (ellL_getmetafield) (ell_State *L, int obj, const char *e);
ELLLIB_API int (ellL_callmeta) (ell_State *L, int obj, const char *e);
ELLLIB_API const char *(ellL_tolstring) (ell_State *L, int idx, size_t *len);
ELLLIB_API int (ellL_argerror) (ell_State *L, int numarg, const char *extramsg);
ELLLIB_API const char *(ellL_checklstring) (ell_State *L, int numArg,
                                                          size_t *l);
ELLLIB_API const char *(ellL_optlstring) (ell_State *L, int numArg,
                                          const char *def, size_t *l);
ELLLIB_API ell_Number (ellL_checknumber) (ell_State *L, int numArg);
ELLLIB_API ell_Number (ellL_optnumber) (ell_State *L, int nArg, ell_Number def);

ELLLIB_API ell_Integer (ellL_checkinteger) (ell_State *L, int numArg);
ELLLIB_API ell_Integer (ellL_optinteger) (ell_State *L, int nArg,
                                          ell_Integer def);
ELLLIB_API ell_Unsigned (ellL_checkunsigned) (ell_State *L, int numArg);
ELLLIB_API ell_Unsigned (ellL_optunsigned) (ell_State *L, int numArg,
                                            ell_Unsigned def);

ELLLIB_API void (ellL_checkstack) (ell_State *L, int sz, const char *msg);
ELLLIB_API void (ellL_checktype) (ell_State *L, int narg, int t);
ELLLIB_API void (ellL_checkany) (ell_State *L, int narg);

ELLLIB_API int   (ellL_newmetatable) (ell_State *L, const char *tname);
ELLLIB_API void  (ellL_setmetatable) (ell_State *L, const char *tname);
ELLLIB_API void *(ellL_testudata) (ell_State *L, int ud, const char *tname);
ELLLIB_API void *(ellL_checkudata) (ell_State *L, int ud, const char *tname);

ELLLIB_API void (ellL_where) (ell_State *L, int lvl);
ELLLIB_API int (ellL_error) (ell_State *L, const char *fmt, ...);

ELLLIB_API int (ellL_checkoption) (ell_State *L, int narg, const char *def,
                                   const char *const lst[]);

ELLLIB_API int (ellL_fileresult) (ell_State *L, int stat, const char *fname);
ELLLIB_API int (ellL_execresult) (ell_State *L, int stat);

/* pre-defined references */
#define ELL_NOREF       (-2)
#define ELL_REFNIL      (-1)

ELLLIB_API int (ellL_ref) (ell_State *L, int t);
ELLLIB_API void (ellL_unref) (ell_State *L, int t, int ref);

ELLLIB_API int (ellL_loadfilex) (ell_State *L, const char *filename,
                                               const char *mode);

#define ellL_loadfile(L,f)	ellL_loadfilex(L,f,NULL)

ELLLIB_API int (ellL_loadbufferx) (ell_State *L, const char *buff, size_t sz,
                                   const char *name, const char *mode);
ELLLIB_API int (ellL_loadstring) (ell_State *L, const char *s);

ELLLIB_API ell_State *(ellL_newstate) (void);

ELLLIB_API int (ellL_len) (ell_State *L, int idx);

ELLLIB_API const char *(ellL_gsub) (ell_State *L, const char *s, const char *p,
                                                  const char *r);

ELLLIB_API void (ellL_setfuncs) (ell_State *L, const ellL_Reg *l, int nup);

ELLLIB_API int (ellL_getsubtable) (ell_State *L, int idx, const char *fname);

ELLLIB_API void (ellL_traceback) (ell_State *L, ell_State *L1,
                                  const char *msg, int level);

ELLLIB_API void (ellL_requiref) (ell_State *L, const char *modname,
                                 ell_CFunction openf, int glb);

/*
** ===============================================================
** some useful macros
** ===============================================================
*/


#define ellL_newlibtable(L,l)	\
  ell_createtable(L, 0, sizeof(l)/sizeof((l)[0]) - 1)

#define ellL_newlib(L,l)	(ellL_newlibtable(L,l), ellL_setfuncs(L,l,0))

#define ellL_argcheck(L, cond,numarg,extramsg)	\
		((void)((cond) || ellL_argerror(L, (numarg), (extramsg))))
#define ellL_checkstring(L,n)	(ellL_checklstring(L, (n), NULL))
#define ellL_optstring(L,n,d)	(ellL_optlstring(L, (n), (d), NULL))
#define ellL_checkint(L,n)	((int)ellL_checkinteger(L, (n)))
#define ellL_optint(L,n,d)	((int)ellL_optinteger(L, (n), (d)))
#define ellL_checklong(L,n)	((long)ellL_checkinteger(L, (n)))
#define ellL_optlong(L,n,d)	((long)ellL_optinteger(L, (n), (d)))

#define ellL_typename(L,i)	ell_typename(L, ell_type(L,(i)))

#define ellL_dofile(L, fn) \
	(ellL_loadfile(L, fn) || ell_pcall(L, 0, ELL_MULTRET, 0))

#define ellL_dostring(L, s) \
	(ellL_loadstring(L, s) || ell_pcall(L, 0, ELL_MULTRET, 0))

#define ellL_getmetatable(L,n)	(ell_getfield(L, ELL_REGISTRYINDEX, (n)))

#define ellL_opt(L,f,n,d)	(ell_isnoneornil(L,(n)) ? (d) : f(L,(n)))

#define ellL_loadbuffer(L,s,sz,n)	ellL_loadbufferx(L,s,sz,n,NULL)


/*
** {======================================================
** Generic Buffer manipulation
** =======================================================
*/

typedef struct ellL_Buffer {
  char *b;  /* buffer address */
  size_t size;  /* buffer size */
  size_t n;  /* number of characters in buffer */
  ell_State *L;
  char initb[ELLL_BUFFERSIZE];  /* initial buffer */
} ellL_Buffer;


#define ellL_addchar(B,c) \
  ((void)((B)->n < (B)->size || ellL_prepbuffsize((B), 1)), \
   ((B)->b[(B)->n++] = (c)))

#define ellL_addsize(B,s)	((B)->n += (s))

ELLLIB_API void (ellL_buffinit) (ell_State *L, ellL_Buffer *B);
ELLLIB_API char *(ellL_prepbuffsize) (ellL_Buffer *B, size_t sz);
ELLLIB_API void (ellL_addlstring) (ellL_Buffer *B, const char *s, size_t l);
ELLLIB_API void (ellL_addstring) (ellL_Buffer *B, const char *s);
ELLLIB_API void (ellL_addvalue) (ellL_Buffer *B);
ELLLIB_API void (ellL_pushresult) (ellL_Buffer *B);
ELLLIB_API void (ellL_pushresultsize) (ellL_Buffer *B, size_t sz);
ELLLIB_API char *(ellL_buffinitsize) (ell_State *L, ellL_Buffer *B, size_t sz);

#define ellL_prepbuffer(B)	ellL_prepbuffsize(B, ELLL_BUFFERSIZE)

/* }====================================================== */



/*
** {======================================================
** File handles for IO library
** =======================================================
*/

/*
** A file handle is a userdata with metatable 'ELL_FILEHANDLE' and
** initial structure 'ellL_Stream' (it may contain other fields
** after that initial structure).
*/

#define ELL_FILEHANDLE          "FILE*"


typedef struct ellL_Stream {
  FILE *f;  /* stream (NULL for incompletely created streams) */
  ell_CFunction closef;  /* to close stream (NULL for closed streams) */
} ellL_Stream;

/* }====================================================== */



/* compatibility with old module system */
#if defined(ELL_COMPAT_MODULE)

ELLLIB_API void (ellL_pushmodule) (ell_State *L, const char *modname,
                                   int sizehint);
ELLLIB_API void (ellL_openlib) (ell_State *L, const char *libname,
                                const ellL_Reg *l, int nup);

#define ellL_register(L,n,l)	(ellL_openlib(L,(n),(l),0))

#endif


#endif


