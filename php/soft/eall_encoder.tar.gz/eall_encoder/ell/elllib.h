/*
** $Id: elllib.h,v 1.43.1.1 2013/04/12 18:48:47 roberto Exp $
** Ell standard libraries
** See Copyright Notice in ell.h
*/


#ifndef elllib_h
#define elllib_h

#include "ell.h"



ELLMOD_API int (ellopen_base) (ell_State *L);

#define ELL_COLIBNAME	"coroutine"
ELLMOD_API int (ellopen_coroutine) (ell_State *L);

#define ELL_TABLIBNAME	"table"
ELLMOD_API int (ellopen_table) (ell_State *L);

#define ELL_IOLIBNAME	"io"
ELLMOD_API int (ellopen_io) (ell_State *L);

#define ELL_OSLIBNAME	"os"
ELLMOD_API int (ellopen_os) (ell_State *L);

#define ELL_STRLIBNAME	"string"
ELLMOD_API int (ellopen_string) (ell_State *L);

#define ELL_BITLIBNAME	"bit32"
ELLMOD_API int (ellopen_bit32) (ell_State *L);

#define ELL_LOADLIBNAME	"package"
ELLMOD_API int (ellopen_package) (ell_State *L);


/* open all previous libraries */
ELLLIB_API void (ellL_openlibs) (ell_State *L);



#if !defined(ell_assert)
#define ell_assert(x)	((void)0)
#endif


#endif
