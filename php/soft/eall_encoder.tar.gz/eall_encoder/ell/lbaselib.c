/*
** $Id: lbaselib.c,v 1.276.1.1 2013/04/12 18:48:47 roberto Exp $
** Basic library
** See Copyright Notice in ell.h
*/



#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define lbaselib_c
#define ELL_LIB

#include "ell.h"

#include "lauxlib.h"
#include "elllib.h"


static int ellB_print (ell_State *L) {
  int n = ell_gettop(L);  /* number of arguments */
  int i;
  ell_getglobal(L, "tostring");
  for (i=1; i<=n; i++) {
    const char *s;
    size_t l;
    ell_pushvalue(L, -1);  /* function to be called */
    ell_pushvalue(L, i);   /* value to print */
    ell_call(L, 1, 1);
    s = ell_tolstring(L, -1, &l);  /* get result */
    if (s == NULL)
      return ellL_error(L,
         ELL_QL("tostring") " must return a string to " ELL_QL("print"));
    if (i>1) elli_writestring("\t", 1);
    elli_writestring(s, l);
    ell_pop(L, 1);  /* pop result */
  }
  elli_writeline();
  return 0;
}


#define SPACECHARS	" \f\n\r\t\v"

static int ellB_tonumber (ell_State *L) {
  if (ell_isnoneornil(L, 2)) {  /* standard conversion */
    int isnum;
    ell_Number n = ell_tonumberx(L, 1, &isnum);
    if (isnum) {
      ell_pushnumber(L, n);
      return 1;
    }  /* else not a number; must be something */
    ellL_checkany(L, 1);
  }
  else {
    size_t l;
    const char *s = ellL_checklstring(L, 1, &l);
    const char *e = s + l;  /* end point for 's' */
    int base = ellL_checkint(L, 2);
    int neg = 0;
    ellL_argcheck(L, 2 <= base && base <= 36, 2, "base out of range");
    s += strspn(s, SPACECHARS);  /* skip initial spaces */
    if (*s == '-') { s++; neg = 1; }  /* handle signal */
    else if (*s == '+') s++;
    if (isalnum((unsigned char)*s)) {
      ell_Number n = 0;
      do {
        int digit = (isdigit((unsigned char)*s)) ? *s - '0'
                       : toupper((unsigned char)*s) - 'A' + 10;
        if (digit >= base) break;  /* invalid numeral; force a fail */
        n = n * (ell_Number)base + (ell_Number)digit;
        s++;
      } while (isalnum((unsigned char)*s));
      s += strspn(s, SPACECHARS);  /* skip trailing spaces */
      if (s == e) {  /* no invalid trailing characters? */
        ell_pushnumber(L, (neg) ? -n : n);
        return 1;
      }  /* else not a number */
    }  /* else not a number */
  }
  ell_pushnil(L);  /* not a number */
  return 1;
}


static int ellB_error (ell_State *L) {
  int level = ellL_optint(L, 2, 1);
  ell_settop(L, 1);
  if (ell_isstring(L, 1) && level > 0) {  /* add extra information? */
    ellL_where(L, level);
    ell_pushvalue(L, 1);
    ell_concat(L, 2);
  }
  return ell_error(L);
}


static int ellB_getmetatable (ell_State *L) {
  ellL_checkany(L, 1);
  if (!ell_getmetatable(L, 1)) {
    ell_pushnil(L);
    return 1;  /* no metatable */
  }
  ellL_getmetafield(L, 1, "__metatable");
  return 1;  /* returns either __metatable field (if present) or metatable */
}


static int ellB_setmetatable (ell_State *L) {
  int t = ell_type(L, 2);
  ellL_checktype(L, 1, ELL_TTABLE);
  ellL_argcheck(L, t == ELL_TNIL || t == ELL_TTABLE, 2,
                    "nil or table expected");
  if (ellL_getmetafield(L, 1, "__metatable"))
    return ellL_error(L, "cannot change a protected metatable");
  ell_settop(L, 2);
  ell_setmetatable(L, 1);
  return 1;
}


static int ellB_rawequal (ell_State *L) {
  ellL_checkany(L, 1);
  ellL_checkany(L, 2);
  ell_pushboolean(L, ell_rawequal(L, 1, 2));
  return 1;
}


static int ellB_rawlen (ell_State *L) {
  int t = ell_type(L, 1);
  ellL_argcheck(L, t == ELL_TTABLE || t == ELL_TSTRING, 1,
                   "table or string expected");
  ell_pushinteger(L, ell_rawlen(L, 1));
  return 1;
}


static int ellB_rawget (ell_State *L) {
  ellL_checktype(L, 1, ELL_TTABLE);
  ellL_checkany(L, 2);
  ell_settop(L, 2);
  ell_rawget(L, 1);
  return 1;
}

static int ellB_rawset (ell_State *L) {
  ellL_checktype(L, 1, ELL_TTABLE);
  ellL_checkany(L, 2);
  ellL_checkany(L, 3);
  ell_settop(L, 3);
  ell_rawset(L, 1);
  return 1;
}


static int ellB_collectgarbage (ell_State *L) {
  static const char *const opts[] = {"stop", "restart", "collect",
    "count", "step", "setpause", "setstepmul",
    "setmajorinc", "isrunning", "generational", "incremental", NULL};
  static const int optsnum[] = {ELL_GCSTOP, ELL_GCRESTART, ELL_GCCOLLECT,
    ELL_GCCOUNT, ELL_GCSTEP, ELL_GCSETPAUSE, ELL_GCSETSTEPMUL,
    ELL_GCSETMAJORINC, ELL_GCISRUNNING, ELL_GCGEN, ELL_GCINC};
  int o = optsnum[ellL_checkoption(L, 1, "collect", opts)];
  int ex = ellL_optint(L, 2, 0);
  int res = ell_gc(L, o, ex);
  switch (o) {
    case ELL_GCCOUNT: {
      int b = ell_gc(L, ELL_GCCOUNTB, 0);
      ell_pushnumber(L, res + ((ell_Number)b/1024));
      ell_pushinteger(L, b);
      return 2;
    }
    case ELL_GCSTEP: case ELL_GCISRUNNING: {
      ell_pushboolean(L, res);
      return 1;
    }
    default: {
      ell_pushinteger(L, res);
      return 1;
    }
  }
}


static int ellB_type (ell_State *L) {
  ellL_checkany(L, 1);
  ell_pushstring(L, ellL_typename(L, 1));
  return 1;
}


static int pairsmeta (ell_State *L, const char *method, int iszero,
                      ell_CFunction iter) {
  if (!ellL_getmetafield(L, 1, method)) {  /* no metamethod? */
    ellL_checktype(L, 1, ELL_TTABLE);  /* argument must be a table */
    ell_pushcfunction(L, iter);  /* will return generator, */
    ell_pushvalue(L, 1);  /* state, */
    if (iszero) ell_pushinteger(L, 0);  /* and initial value */
    else ell_pushnil(L);
  }
  else {
    ell_pushvalue(L, 1);  /* argument 'self' to metamethod */
    ell_call(L, 1, 3);  /* get 3 values from metamethod */
  }
  return 3;
}


static int ellB_next (ell_State *L) {
  ellL_checktype(L, 1, ELL_TTABLE);
  ell_settop(L, 2);  /* create a 2nd argument if there isn't one */
  if (ell_next(L, 1))
    return 2;
  else {
    ell_pushnil(L);
    return 1;
  }
}


static int ellB_pairs (ell_State *L) {
  return pairsmeta(L, "__pairs", 0, ellB_next);
}


static int ipairsaux (ell_State *L) {
  int i = ellL_checkint(L, 2);
  ellL_checktype(L, 1, ELL_TTABLE);
  i++;  /* next value */
  ell_pushinteger(L, i);
  ell_rawgeti(L, 1, i);
  return (ell_isnil(L, -1)) ? 1 : 2;
}


static int ellB_ipairs (ell_State *L) {
  return pairsmeta(L, "__ipairs", 1, ipairsaux);
}


static int load_aux (ell_State *L, int status, int envidx) {
  if (status == ELL_OK) {
    if (envidx != 0) {  /* 'env' parameter? */
      ell_pushvalue(L, envidx);  /* environment for loaded function */
      if (!ell_setupvalue(L, -2, 1))  /* set it as 1st upvalue */
        ell_pop(L, 1);  /* remove 'env' if not used by previous call */
    }
    return 1;
  }
  else {  /* error (message is on top of the stack) */
    ell_pushnil(L);
    ell_insert(L, -2);  /* put before error message */
    return 2;  /* return nil plus error message */
  }
}


static int ellB_loadfile (ell_State *L) {
  const char *fname = ellL_optstring(L, 1, NULL);
  const char *mode = ellL_optstring(L, 2, NULL);
  int env = (!ell_isnone(L, 3) ? 3 : 0);  /* 'env' index or 0 if no 'env' */
  int status = ellL_loadfilex(L, fname, mode);
  return load_aux(L, status, env);
}


/*
** {======================================================
** Generic Read function
** =======================================================
*/


/*
** reserved slot, above all arguments, to hold a copy of the returned
** string to avoid it being collected while parsed. 'load' has four
** optional arguments (chunk, source name, mode, and environment).
*/
#define RESERVEDSLOT	5


/*
** Reader for generic `load' function: `ell_load' uses the
** stack for internal stuff, so the reader cannot change the
** stack top. Instead, it keeps its resulting string in a
** reserved slot inside the stack.
*/
static const char *generic_reader (ell_State *L, void *ud, size_t *size) {
  (void)(ud);  /* not used */
  ellL_checkstack(L, 2, "too many nested functions");
  ell_pushvalue(L, 1);  /* get function */
  ell_call(L, 0, 1);  /* call it */
  if (ell_isnil(L, -1)) {
    ell_pop(L, 1);  /* pop result */
    *size = 0;
    return NULL;
  }
  else if (!ell_isstring(L, -1))
    ellL_error(L, "reader function must return a string");
  ell_replace(L, RESERVEDSLOT);  /* save string in reserved slot */
  return ell_tolstring(L, RESERVEDSLOT, size);
}


static int ellB_load (ell_State *L) {
  int status;
  size_t l;
  const char *s = ell_tolstring(L, 1, &l);
  const char *mode = ellL_optstring(L, 3, "bt");
  int env = (!ell_isnone(L, 4) ? 4 : 0);  /* 'env' index or 0 if no 'env' */
  if (s != NULL) {  /* loading a string? */
    const char *chunkname = ellL_optstring(L, 2, s);
    status = ellL_loadbufferx(L, s, l, chunkname, mode);
  }
  else {  /* loading from a reader function */
    const char *chunkname = ellL_optstring(L, 2, "=(load)");
    ellL_checktype(L, 1, ELL_TFUNCTION);
    ell_settop(L, RESERVEDSLOT);  /* create reserved slot */
    status = ell_load(L, generic_reader, NULL, chunkname, mode);
  }
  return load_aux(L, status, env);
}

/* }====================================================== */


static int dofilecont (ell_State *L) {
  return ell_gettop(L) - 1;
}


static int ellB_dofile (ell_State *L) {
  const char *fname = ellL_optstring(L, 1, NULL);
  ell_settop(L, 1);
  if (ellL_loadfile(L, fname) != ELL_OK)
    return ell_error(L);
  ell_callk(L, 0, ELL_MULTRET, 0, dofilecont);
  return dofilecont(L);
}


static int ellB_assert (ell_State *L) {
  if (!ell_toboolean(L, 1))
    return ellL_error(L, "%s", ellL_optstring(L, 2, "assertion failed!"));
  return ell_gettop(L);
}


static int ellB_select (ell_State *L) {
  int n = ell_gettop(L);
  if (ell_type(L, 1) == ELL_TSTRING && *ell_tostring(L, 1) == '#') {
    ell_pushinteger(L, n-1);
    return 1;
  }
  else {
    int i = ellL_checkint(L, 1);
    if (i < 0) i = n + i;
    else if (i > n) i = n;
    ellL_argcheck(L, 1 <= i, 1, "index out of range");
    return n - i;
  }
}


static int finishpcall (ell_State *L, int status) {
  if (!ell_checkstack(L, 1)) {  /* no space for extra boolean? */
    ell_settop(L, 0);  /* create space for return values */
    ell_pushboolean(L, 0);
    ell_pushstring(L, "stack overflow");
    return 2;  /* return false, msg */
  }
  ell_pushboolean(L, status);  /* first result (status) */
  ell_replace(L, 1);  /* put first result in first slot */
  return ell_gettop(L);
}


static int pcallcont (ell_State *L) {
  int status = ell_getctx(L, NULL);
  return finishpcall(L, (status == ELL_YIELD));
}


static int ellB_pcall (ell_State *L) {
  int status;
  ellL_checkany(L, 1);
  ell_pushnil(L);
  ell_insert(L, 1);  /* create space for status result */
  status = ell_pcallk(L, ell_gettop(L) - 2, ELL_MULTRET, 0, 0, pcallcont);
  return finishpcall(L, (status == ELL_OK));
}


static int ellB_xpcall (ell_State *L) {
  int status;
  int n = ell_gettop(L);
  ellL_argcheck(L, n >= 2, 2, "value expected");
  ell_pushvalue(L, 1);  /* exchange function... */
  ell_copy(L, 2, 1);  /* ...and error handler */
  ell_replace(L, 2);
  status = ell_pcallk(L, n - 2, ELL_MULTRET, 1, 0, pcallcont);
  return finishpcall(L, (status == ELL_OK));
}


static int ellB_tostring (ell_State *L) {
  ellL_checkany(L, 1);
  ellL_tolstring(L, 1, NULL);
  return 1;
}


static const ellL_Reg base_funcs[] = {
  {"assert", ellB_assert},
  {"collectgarbage", ellB_collectgarbage},
  {"dofile", ellB_dofile},
  {"error", ellB_error},
  {"getmetatable", ellB_getmetatable},
  {"ipairs", ellB_ipairs},
  {"loadfile", ellB_loadfile},
  {"load", ellB_load},
#if defined(ELL_COMPAT_LOADSTRING)
  {"loadstring", ellB_load},
#endif
  {"next", ellB_next},
  {"pairs", ellB_pairs},
  {"pcall", ellB_pcall},
  {"print", ellB_print},
  {"rawequal", ellB_rawequal},
  {"rawlen", ellB_rawlen},
  {"rawget", ellB_rawget},
  {"rawset", ellB_rawset},
  {"select", ellB_select},
  {"setmetatable", ellB_setmetatable},
  {"tonumber", ellB_tonumber},
  {"tostring", ellB_tostring},
  {"type", ellB_type},
  {"xpcall", ellB_xpcall},
  {NULL, NULL}
};


ELLMOD_API int ellopen_base (ell_State *L) {
  /* set global _G */
  ell_pushglobaltable(L);
  ell_pushglobaltable(L);
  ell_setfield(L, -2, "_G");
  /* open lib into global table */
  ellL_setfuncs(L, base_funcs, 0);
  ell_pushliteral(L, ELL_VERSION);
  ell_setfield(L, -2, "_VERSION");  /* set global _VERSION */
  return 1;
}

