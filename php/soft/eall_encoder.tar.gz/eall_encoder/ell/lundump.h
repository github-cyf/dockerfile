/*
** $Id: lundump.h,v 1.39.1.1 2013/04/12 18:48:47 roberto Exp $
** load precompiled Ell chunks
** See Copyright Notice in ell.h
*/

#ifndef lundump_h
#define lundump_h

#include "lobject.h"
#include "lzio.h"

void ellU_setbit(int bit);
int ellU_getbit();

/* load one chunk; from lundump.c */
ELLI_FUNC Closure* ellU_undump (ell_State* L, ZIO* Z, Mbuffer* buff, const char* name);

/* make header; from lundump.c */
ELLI_FUNC void ellU_header (lu_byte* h);

/* dump one chunk; from ldump.c */
ELLI_FUNC int ellU_dump (ell_State* L, const Proto* f, ell_Writer w, void* data, int strip);

/* data to catch conversion errors */
#define ELLC_TAIL		"\x19\x93\r\n\x1a\n"

/* size in bytes of header of binary files */
#define ELLC_HEADERSIZE		(sizeof(ELL_SIGNATURE)-sizeof(char)+2+6+sizeof(ELLC_TAIL)-sizeof(char))

#endif
