/*
** $Id: lbitlib.c,v 1.18.1.2 2013/07/09 18:01:41 roberto Exp $
** Standard library for bitwise operations
** See Copyright Notice in ell.h
*/

#define lbitlib_c
#define ELL_LIB

#include "ell.h"

#include "lauxlib.h"
#include "elllib.h"


/* number of bits to consider in a number */
#if !defined(ELL_NBITS)
#define ELL_NBITS	32
#endif


#define ALLONES		(~(((~(ell_Unsigned)0) << (ELL_NBITS - 1)) << 1))

/* macro to trim extra bits */
#define trim(x)		((x) & ALLONES)


/* builds a number with 'n' ones (1 <= n <= ELL_NBITS) */
#define mask(n)		(~((ALLONES << 1) << ((n) - 1)))


typedef ell_Unsigned b_uint;



static b_uint andaux (ell_State *L) {
  int i, n = ell_gettop(L);
  b_uint r = ~(b_uint)0;
  for (i = 1; i <= n; i++)
    r &= ellL_checkunsigned(L, i);
  return trim(r);
}


static int b_and (ell_State *L) {
  b_uint r = andaux(L);
  ell_pushunsigned(L, r);
  return 1;
}


static int b_test (ell_State *L) {
  b_uint r = andaux(L);
  ell_pushboolean(L, r != 0);
  return 1;
}


static int b_or (ell_State *L) {
  int i, n = ell_gettop(L);
  b_uint r = 0;
  for (i = 1; i <= n; i++)
    r |= ellL_checkunsigned(L, i);
  ell_pushunsigned(L, trim(r));
  return 1;
}


static int b_xor (ell_State *L) {
  int i, n = ell_gettop(L);
  b_uint r = 0;
  for (i = 1; i <= n; i++)
    r ^= ellL_checkunsigned(L, i);
  ell_pushunsigned(L, trim(r));
  return 1;
}


static int b_not (ell_State *L) {
  b_uint r = ~ellL_checkunsigned(L, 1);
  ell_pushunsigned(L, trim(r));
  return 1;
}


static int b_shift (ell_State *L, b_uint r, int i) {
  if (i < 0) {  /* shift right? */
    i = -i;
    r = trim(r);
    if (i >= ELL_NBITS) r = 0;
    else r >>= i;
  }
  else {  /* shift left */
    if (i >= ELL_NBITS) r = 0;
    else r <<= i;
    r = trim(r);
  }
  ell_pushunsigned(L, r);
  return 1;
}


static int b_lshift (ell_State *L) {
  return b_shift(L, ellL_checkunsigned(L, 1), ellL_checkint(L, 2));
}


static int b_rshift (ell_State *L) {
  return b_shift(L, ellL_checkunsigned(L, 1), -ellL_checkint(L, 2));
}


static int b_arshift (ell_State *L) {
  b_uint r = ellL_checkunsigned(L, 1);
  int i = ellL_checkint(L, 2);
  if (i < 0 || !(r & ((b_uint)1 << (ELL_NBITS - 1))))
    return b_shift(L, r, -i);
  else {  /* arithmetic shift for 'negative' number */
    if (i >= ELL_NBITS) r = ALLONES;
    else
      r = trim((r >> i) | ~(~(b_uint)0 >> i));  /* add signal bit */
    ell_pushunsigned(L, r);
    return 1;
  }
}


static int b_rot (ell_State *L, int i) {
  b_uint r = ellL_checkunsigned(L, 1);
  i &= (ELL_NBITS - 1);  /* i = i % NBITS */
  r = trim(r);
  if (i != 0)  /* avoid undefined shift of ELL_NBITS when i == 0 */
    r = (r << i) | (r >> (ELL_NBITS - i));
  ell_pushunsigned(L, trim(r));
  return 1;
}


static int b_lrot (ell_State *L) {
  return b_rot(L, ellL_checkint(L, 2));
}


static int b_rrot (ell_State *L) {
  return b_rot(L, -ellL_checkint(L, 2));
}


/*
** get field and width arguments for field-manipulation functions,
** checking whether they are valid.
** ('ellL_error' called without 'return' to avoid later warnings about
** 'width' being used uninitialized.)
*/
static int fieldargs (ell_State *L, int farg, int *width) {
  int f = ellL_checkint(L, farg);
  int w = ellL_optint(L, farg + 1, 1);
  ellL_argcheck(L, 0 <= f, farg, "field cannot be negative");
  ellL_argcheck(L, 0 < w, farg + 1, "width must be positive");
  if (f + w > ELL_NBITS)
    ellL_error(L, "trying to access non-existent bits");
  *width = w;
  return f;
}


static int b_extract (ell_State *L) {
  int w;
  b_uint r = ellL_checkunsigned(L, 1);
  int f = fieldargs(L, 2, &w);
  r = (r >> f) & mask(w);
  ell_pushunsigned(L, r);
  return 1;
}


static int b_replace (ell_State *L) {
  int w;
  b_uint r = ellL_checkunsigned(L, 1);
  b_uint v = ellL_checkunsigned(L, 2);
  int f = fieldargs(L, 3, &w);
  int m = mask(w);
  v &= m;  /* erase bits outside given width */
  r = (r & ~(m << f)) | (v << f);
  ell_pushunsigned(L, r);
  return 1;
}


static const ellL_Reg bitlib[] = {
  {"arshift", b_arshift},
  {"band", b_and},
  {"bnot", b_not},
  {"bor", b_or},
  {"bxor", b_xor},
  {"btest", b_test},
  {"extract", b_extract},
  {"lrotate", b_lrot},
  {"lshift", b_lshift},
  {"replace", b_replace},
  {"rrotate", b_rrot},
  {"rshift", b_rshift},
  {NULL, NULL}
};



ELLMOD_API int ellopen_bit32 (ell_State *L) {
  ellL_newlib(L, bitlib);
  return 1;
}

