/*
** $Id: lvm.h,v 2.18.1.1 2013/04/12 18:48:47 roberto Exp $
** Ell virtual machine
** See Copyright Notice in ell.h
*/

#ifndef lvm_h
#define lvm_h


#include "ldo.h"
#include "lobject.h"
#include "ltm.h"


#define tostring(L,o) (ttisstring(o) || (ellV_tostring(L, o)))

#define tonumber(o,n)	(ttisnumber(o) || (((o) = ellV_tonumber(o,n)) != NULL))

#define equalobj(L,o1,o2)  (ttisequal(o1, o2) && ellV_equalobj_(L, o1, o2))

#define ellV_rawequalobj(o1,o2)		equalobj(NULL,o1,o2)


/* not to called directly */
ELLI_FUNC int ellV_equalobj_ (ell_State *L, const TValue *t1, const TValue *t2);


ELLI_FUNC int ellV_lessthan (ell_State *L, const TValue *l, const TValue *r);
ELLI_FUNC int ellV_lessequal (ell_State *L, const TValue *l, const TValue *r);
ELLI_FUNC const TValue *ellV_tonumber (const TValue *obj, TValue *n);
ELLI_FUNC int ellV_tostring (ell_State *L, StkId obj);
ELLI_FUNC void ellV_gettable (ell_State *L, const TValue *t, TValue *key,
                                            StkId val);
ELLI_FUNC void ellV_settable (ell_State *L, const TValue *t, TValue *key,
                                            StkId val);
ELLI_FUNC void ellV_finishOp (ell_State *L);
ELLI_FUNC void ellV_execute (ell_State *L);
ELLI_FUNC void ellV_concat (ell_State *L, int total);
ELLI_FUNC void ellV_arith (ell_State *L, StkId ra, const TValue *rb,
                           const TValue *rc, TMS op);
ELLI_FUNC void ellV_objlen (ell_State *L, StkId ra, const TValue *rb);

#endif
