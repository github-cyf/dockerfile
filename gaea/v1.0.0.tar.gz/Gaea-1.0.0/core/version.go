package core

const (
	// Version means gaea version
	Version = "2019-05-22 17:07:20 +0800 @748fcd3"
	// Compile means gaea compole info
	Compile = "2019-05-24 10:34:46 +0800 by go version go1.11.4 linux/amd64"
)
